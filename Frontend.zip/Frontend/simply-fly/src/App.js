import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import LandingPage from './components/LandingPage';
import Login from './components/Auth/Login';
import Register from './components/Auth/Register';
import PassengerDashboard from './components/Passenger/PassengerDashboard';
import OwnerDashboard from './components/FlightOwner/FlightOwnerDashboard';
import AdminDashboard from './components/Admin/AdminDashboard';
import UsersList from './components/Admin/UserList';
import UserForm  from './components/Admin/UserForm';
import FlightsList from './components/Admin/FlightsList';
import FlightForm  from './components/Admin/FlightForm';
 import RoutesList from './components/Admin/RoutesList';
import RouteForm  from './components/Admin/RouteForm';
import AdminProfile from './components/Admin/AdminProfile';
import SearchResults from './components/Passenger/SearchResult';
import SeatSelection  from './components/Passenger/SeatSelection';
import PassengerBookings from './components/Passenger/BookingList';
import BookingDetails from './components/Passenger/BookingDetails';
import PassengerProfile from './components/Passenger/PassengerProfile';
import MyFlights from './components/FlightOwner/MyFlights';
import MyRoutes from './components/FlightOwner/MyRoutes';
import OwnerProfile from './components/FlightOwner/OwnerProfile';
import FlightFormOwner from './components/FlightOwner/FlightFormOwner';
import RouteFormFlightOwner from './components/FlightOwner/RouteFormFlightOwner';
import NewBooking from './components/Passenger/NewBooking';
import BookingDetailsAdmin from './components/Admin/BookingDetails';
import BookingsList from './components/Admin/BookingsList';
import PaymentSuccess from './components/Passenger/PaymentSuccess';
import BookingHistory from './components/Passenger/BookingHistory';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route path="/owner" element={<OwnerDashboard />} />
        <Route path="/flights" element={<MyFlights />} />
        <Route path="/flightForm/:id" element={<FlightFormOwner />} />
        <Route path="/flightForm" element={<FlightFormOwner />} />
        <Route path="/routes" element={<MyRoutes />} />
        <Route path="/routeForm/:id" element={<RouteFormFlightOwner />} />
        <Route path="/routeForm" element={<RouteFormFlightOwner />} />


        <Route path="/profile" element={<OwnerProfile />} />
        <Route path="/admin" element={<AdminDashboard />} />

        <Route path="/users" element={<UsersList />} />
        <Route path="/users/new" element={<UserForm />} />
        <Route path="/users/:id"  element={<UserForm />} />

        <Route path="/flightsAdmin" element={<FlightsList />} />
        <Route path="/flights/new" element={<FlightForm />} />
        <Route path="/flights/:id" element={<FlightForm />} />

        <Route path="/bookings"    element={<BookingsList />} />

        <Route path="/routesAdmin"       element={<RoutesList />} />
        <Route path="/routes/new"   element={<RouteForm />} />
        <Route path="/routes/:id"   element={<RouteForm />} />
        <Route path="/profileAdmin" element={<AdminProfile />} />
<Route path="/bookingsAdmin/:bookingId" element={<BookingDetailsAdmin />} />

        <Route path="/passenger/dashboard" element={<PassengerDashboard />} />
        <Route path="/passenger/dashboard/search" element={<SearchResults />} />
        <Route path="/passenger/dashboard/seats/:routeId" element={<SeatSelection />} />
        <Route path="/passenger/dashboard/bookings" element={<PassengerBookings />} />
        <Route path="/passenger/dashboard/bookings/:bookingId" element={<BookingDetails />} />
        <Route path="/passenger/dashboard/profile" element={<PassengerProfile />} />
        <Route path="/passenger/dashboard/newBooking" element={<NewBooking />} />
          <Route path="/payment-success"  element={<PaymentSuccess />} />
<Route path="/passenger/dashboard/history" element={<BookingHistory />} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
