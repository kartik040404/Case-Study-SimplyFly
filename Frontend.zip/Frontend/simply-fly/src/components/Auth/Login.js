import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBar from '../NavBar';
import bgImage from '../assets/images/login.png'; 

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]       = useState('');

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    try {
      const response = await fetch(
        `${process.env.REACT_APP_BASE_URL}/api/auth/login`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        }
      );
      const body = await response.json();
      if (response.ok && body.success) {
        localStorage.setItem('token', body.token);
        localStorage.setItem('user', JSON.stringify(body.data));
        const role = body.data.role;
        switch (role) {
          case 'PASSENGER':
            navigate('/passenger/dashboard', { replace: true });
            break;
          case 'FLIGHT_OWNER':
            navigate('/owner', { replace: true });
            break;
          case 'ADMIN':
            navigate('/admin', { replace: true });
            break;
          default:
            navigate('/login', { replace: true });
        }
      } else {
        setError(body.message || 'Login failed');
      }
    } catch {
      setError('Server error, please try again');
    }
  };

  return (
    <>

      <div
        className="d-flex align-items-center"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          minHeight: '100vh',
        }}
      >
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div
                className="p-5 shadow-lg"
                style={{
                  maxWidth: '480px',
                  borderRadius: '2rem',
                  background: 'rgba(255, 255, 255, 0.2)',
                  backdropFilter: 'blur(10px)',
                  WebkitBackdropFilter: 'blur(10px)'
                }}
              >
                <h2 className="text-center mb-4 text-white">Login</h2>
                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <input
                      type="email"
                      className="form-control form-control-lg rounded-pill"
                      placeholder="Email address"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  <div className="mb-4">
                    <input
                      type="password"
                      className="form-control form-control-lg rounded-pill"
                      placeholder="Password"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="btn btn-primary btn-lg w-100 rounded-pill"
                  >
                    Login
                  </button>
                </form>
                <div className="text-center mt-4">
                  <small className="text-dark">
                    Don't have an account?{' '}
                    <span
                      className="text-dark fw-bold"
                      style={{ cursor: 'pointer', textDecoration: 'underline' }}
                      onClick={() => navigate('/register')}
                    >
                      Sign Up
                    </span>
                  </small>
                </div>
                {error && (
                  <p className="text-danger mt-3 text-center">{error}</p>
                )}
              </div>
            </div>

            <div className="col-md-6"></div>
          </div>
        </div>
      </div>
    </>
  );
}
