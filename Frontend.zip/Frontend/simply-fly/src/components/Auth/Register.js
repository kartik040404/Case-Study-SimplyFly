import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBar from '../NavBar';
import bgImage from '../assets/images/register.png'; 

export default function Register() {
  const navigate = useNavigate();
  const [error, setError] = useState('');
  const [user, setUser] = useState({
    name: '',
    email: '',
    password: '',
    gender: '',
    contactNumber: '',
    address: ''
  });

  const handleChange = e =>
    setUser(u => ({ ...u, [e.target.name]: e.target.value }));

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    try {
      const response = await fetch(
        `${process.env.REACT_APP_BASE_URL}/api/auth/register`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(user)
        }
      );
      if (response.ok) {
        navigate('/login', { replace: true });
      } else {
        setError('Registration failed');
      }
    } catch {
      setError('Server error, please try again');
    }
  };

  return (
    <>

      <div
        className="d-flex align-items-center"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          minHeight: '100vh'
        }}
      >
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div
                className="p-4 shadow-lg"
                style={{
                  maxWidth: '420px',
                  borderRadius: '1.5rem',
                  background: 'rgba(255, 255, 255, 0.2)',
                  backdropFilter: 'blur(10px)',
                  WebkitBackdropFilter: 'blur(10px)'
                }}
              >
                <h4 className="text-white text-center mb-3">Sign Up</h4>
                <form onSubmit={handleSubmit}>
                  {['name', 'email', 'password', 'gender', 'contactNumber', 'address'].map(field => (
                    <div className="mb-3" key={field}>
                      <label htmlFor={field} className="form-label text-white small">
                        {field === 'contactNumber'
                          ? 'Contact Number'
                          : field.charAt(0).toUpperCase() + field.slice(1)}
                      </label>
                      <input
                        id={field}
                        name={field}
                        type={field === 'password' ? 'password' : 'text'}
                        className="form-control form-control-sm rounded-pill"
                        placeholder={`Enter your ${field === 'contactNumber' ? 'contact number' : field}`}
                        value={user[field]}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  ))}

                  <button
                    type="submit"
                    className="btn btn-primary btn-sm w-100 rounded-pill mt-2"
                  >
                    Register
                  </button>
                </form>

                <div className="text-center mt-3">
                  <small className="text-white">
                    Already have an account?{' '}
                    <span
                      className="fw-bold"
                      style={{ cursor: 'pointer', textDecoration: 'underline' }}
                      onClick={() => navigate('/login')}
                    >
                      Login
                    </span>
                  </small>
                </div>

                {error && (
                  <p className="text-danger small mt-2 text-center">{error}</p>
                )}
              </div>
            </div>

            <div className="col-md-6"></div>
          </div>
        </div>
      </div>
    </>
  );
}
