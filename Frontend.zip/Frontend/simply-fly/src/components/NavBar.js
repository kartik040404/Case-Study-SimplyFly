// src/components/NavBar.jsx
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function NavBar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login', { replace: true });
  };

  return (
    <nav
      className="navbar navbar-expand-lg navbar-light bg-black shadow-sm rounded-bottom"
    >
      <div className="container">
        <Link className="navbar-brand fw-bold text-white" to="/admin">
          SimplyFly
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#adminNavbar"
          aria-controls="adminNavbar"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>

        <div className="collapse navbar-collapse" id="adminNavbar">
          <ul className="navbar-nav ms-auto align-items-center">
            <li className="nav-item mx-2">
              <Link className="nav-link text-white" to="/users">
                Users
              </Link>
            </li>
            <li className="nav-item mx-2">
              <Link className="nav-link text-white" to="/flightsAdmin">
                Flights
              </Link>
            </li>
            <li className="nav-item mx-2">
              <Link className="nav-link text-white" to="/routesAdmin">
                Routes
              </Link>
            </li>
            <li className="nav-item mx-2">
              <Link className="nav-link text-white" to="/bookings">
                Bookings
              </Link>
            </li>
            <li className="nav-item mx-2">
              <Link className="nav-link text-white" to="/profileAdmin">
                Profile
              </Link>
            </li>
            <li className="nav-item mx-2">
              <button
                className="btn btn-outline-dark rounded-pill text-white"
                onClick={handleLogout}
              >
                Logout
              </button>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
