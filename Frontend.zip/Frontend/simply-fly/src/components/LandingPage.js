// src/components/LandingPage.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';
import planeImg from './assets/images/landingImage.png';

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div
      className="container-fluid vh-100 p-0"
      style={{
        backgroundImage: `url(${planeImg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      <div className="row g-0 h-100">
        {/* left panel */}
        <div className="col-md-6 d-flex flex-column justify-content-center align-items-start px-5 ">
          <h1 className="display-4 fw-bold text-white mb-3">Welcome to SimplyFly</h1>
          <p className="lead text-white mb-4">
            Book flights, manage reservations, and enjoy seamless travel—all in one place.
          </p>
          <div>
            <button
              className="btn btn-light btn-lg rounded-pill me-3"
              onClick={() => navigate('/register')}
            >
              Sign Up
            </button>
            <button
              className="btn btn-outline-light btn-lg rounded-pill"
              onClick={() => navigate('/login')}
            >
              Sign In
            </button>
          </div>
        </div>

        {/* right panel stays empty, background shows through */}
        <div className="col-md-6"></div>
      </div>
    </div>
  );
}
