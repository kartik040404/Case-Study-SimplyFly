import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const SearchBar = ({ allRoutes = [] }) => {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [date, setDate] = useState('');
  const [originSuggestions, setOriginSuggestions] = useState([]);
  const [destinationSuggestions, setDestinationSuggestions] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    setOrigin(params.get('origin') || '');
    setDestination(params.get('destination') || '');
    setDate(params.get('date') || '');
  }, [location.search]);

  const uniqueOrigins = [...new Set(allRoutes.map(r => r.origin))];
  const uniqueDestinations = [...new Set(allRoutes.map(r => r.destination))];

  const filterSuggestions = (input, list) =>
    list.filter(city =>
      city.toLowerCase().startsWith(input.toLowerCase())
    );

  const handleOriginChange = (e) => {
    const val = e.target.value;
    setOrigin(val);
    setOriginSuggestions(val ? filterSuggestions(val, uniqueOrigins) : []);
  };

  const handleDestinationChange = (e) => {
    const val = e.target.value;
    setDestination(val);
    setDestinationSuggestions(val ? filterSuggestions(val, uniqueDestinations) : []);
  };

  const applySuggestion = (field, value) => {
    if (field === 'origin') {
      setOrigin(value);
      setOriginSuggestions([]);
    } else {
      setDestination(value);
      setDestinationSuggestions([]);
    }
  };

  const handleSearch = e => {
    e.preventDefault();
    navigate(
      `/passenger/dashboard/search?origin=${origin}&destination=${destination}&date=${date}`
    );
  };

  return (
    <form className="row g-2 mb-4 position-relative" onSubmit={handleSearch}>
      <div className="col-md-4 position-relative">
        <input
          type="text"
          className="form-control rounded-3 border-0 shadow-sm bg-light"
          placeholder="Origin City"
          value={origin}
          onChange={handleOriginChange}
          required
          autoComplete="off"
          style={{ padding: '15px 20px', fontSize: '16px' }}
        />
        {originSuggestions.length > 0 && (
          <ul className="list-group position-absolute w-100 z-3" style={{ top: '100%', maxHeight: '200px', overflowY: 'auto' }}>
            {originSuggestions.map((s, i) => (
              <li
                key={i}
                className="list-group-item list-group-item-action"
                onClick={() => applySuggestion('origin', s)}
                style={{ cursor: 'pointer' }}
              >
                {s}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="col-md-4 position-relative">
        <input
          type="text"
          className="form-control rounded-3 border-0 shadow-sm bg-light"
          placeholder="Destination City"
          value={destination}
          onChange={handleDestinationChange}
          required
          autoComplete="off"
          style={{ padding: '15px 20px', fontSize: '16px' }}
        />
        {destinationSuggestions.length > 0 && (
          <ul className="list-group position-absolute w-100 z-3" style={{ top: '100%', maxHeight: '200px', overflowY: 'auto' }}>
            {destinationSuggestions.map((s, i) => (
              <li
                key={i}
                className="list-group-item list-group-item-action"
                onClick={() => applySuggestion('destination', s)}
                style={{ cursor: 'pointer' }}
              >
                {s}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="col-md-3">
        <input
          type="date"
          className="form-control rounded-3 border-0 shadow-sm bg-light"
          value={date}
          onChange={e => setDate(e.target.value)}
          required
          style={{ padding: '15px 20px', fontSize: '16px' }}
        />
      </div>

      <div className="col-12 d-flex justify-content-center mt-2 ">
        <button
          type="submit"
          className="btn text-white btn-lg rounded-pill shadow"
          style={{
            minWidth: '140px',
            background: 'linear-gradient(135deg, #FF512F 0%, #F09819 100%)'
          }}
        >
          Go
        </button>
      </div>
    </form>
  );
};

export default SearchBar;
