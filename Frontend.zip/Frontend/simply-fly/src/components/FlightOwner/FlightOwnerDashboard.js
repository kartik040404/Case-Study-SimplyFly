// src/components/FlightOwner/OwnerDashboard.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import FlightOwnerNavBar from './FlightOwnerNavBar';
import bgImage from '../assets/images/flightOwnerDashboard.jpg'; // or your preferred background

export default function OwnerDashboard() {
    const stored = localStorage.getItem('user');
  const user = stored ? JSON.parse(stored) : null;
  return (
    <div
      className="position-relative"
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        minHeight: '100vh'
      }}
    >
       <div
        className="position-absolute top-0 start-0 w-100 h-100"
        style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
      />

      <div className="position-relative">
        <FlightOwnerNavBar />

        <div className="container text-white text-center py-5">
           <h1 className="display-3 fw-bold mb-3">Welcome, {user.name}</h1>
          <p className="lead mb-5">
            Manage your flights, routes, and profile all in one place.
          </p>

 
        </div>
      </div>
    </div>
  );
}
