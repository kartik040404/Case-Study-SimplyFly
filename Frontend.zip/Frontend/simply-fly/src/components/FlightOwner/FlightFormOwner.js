import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import FlightOwnerNavBar from './FlightOwnerNavBar';
import bgImage from '../assets/images/addFlight_flight_owner.jpg';

export default function FlightFormOwner() {
  const { id }   = useParams();
  const isEdit   = Boolean(id);
  const navigate = useNavigate();
  const user     = JSON.parse(localStorage.getItem('user') || '{}');

  const [flightNumber, setFlightNumber]               = useState('');
  const [flightName, setFlightName]                   = useState('');
  const [totalSeats, setTotalSeats]                   = useState('');
  const [checkinKg, setCheckinKg]                     = useState('');
  const [cabinKg, setCabinKg]                         = useState('');
  const [economySeats, setEconomySeats]               = useState('');
  const [businessSeats, setBusinessSeats]             = useState('');
  const [premiumEconomySeats, setPremiumEconomySeats] = useState('');
  const [firstClassSeats, setFirstClassSeats]         = useState('');
  const [error, setError]                             = useState('');

  useEffect(() => {
    if (isEdit) {
      const token = localStorage.getItem('token');
      fetch(`${process.env.REACT_APP_BASE_URL}/api/flights/${id}`, {
        headers: { Authorization: 'Bearer ' + token }
      })
        .then(r => r.json())
        .then(b => {
          const f = b.data;
          setFlightNumber(f.flightNumber);
          setFlightName(f.flightName);
          setTotalSeats(f.totalSeats);
          setCheckinKg(f.checkinKg);
          setCabinKg(f.cabinKg);
          setEconomySeats(f.economySeats);
          setBusinessSeats(f.businessSeats);
          setPremiumEconomySeats(f.premiumEconomySeats);
          setFirstClassSeats(f.firstClassSeats);
        })
        .catch(() => setError('Failed to load flight'));
    }
  }, [id, isEdit]);

  useEffect(() => {
  const total =
    parseInt(economySeats || 0, 10) +
    parseInt(businessSeats || 0, 10) +
    parseInt(premiumEconomySeats || 0, 10) +
    parseInt(firstClassSeats || 0, 10);
  setTotalSeats(total);
}, [economySeats, businessSeats, premiumEconomySeats, firstClassSeats]);


  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    const token = localStorage.getItem('token');
    const payload = {
      owner: { userID: user.userID },
      flightNumber,
      flightName,
      totalSeats: parseInt(totalSeats, 10),
      checkinKg: parseInt(checkinKg, 10),
      cabinKg: parseInt(cabinKg, 10),
      economySeats: parseInt(economySeats, 10),
      businessSeats: parseInt(businessSeats, 10),
      premiumEconomySeats: parseInt(premiumEconomySeats, 10),
      firstClassSeats: parseInt(firstClassSeats, 10)
    };
    const url    = isEdit
      ? `${process.env.REACT_APP_BASE_URL}/api/flights/${id}`
      : `${process.env.REACT_APP_BASE_URL}/api/flights`;
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res  = await fetch(url, {
        method,
        headers: {
          'Content-Type':  'application/json',
          Authorization:   'Bearer ' + token
        },
        body: JSON.stringify(payload)
      });
      const body = await res.json();
      if (res.ok && body.success) {
        navigate('/flights', { replace: true });
      } else {
        setError(body.message || 'Failed to save flight');
      }
    } catch {
      setError('Server error, please try again');
    }
  };

  return (
    <>
      <FlightOwnerNavBar />

      <div className="container-fluid p-0">
        <div className="row g-0">
          <div
            className="col-md-6 d-none d-md-block"
            style={{
              backgroundImage:    `url(${bgImage})`,
              backgroundSize:     'cover',
              backgroundPosition: 'center',
              minHeight:          '92vh'
            }}
          />

          <div className="col-md-6 d-flex align-items-center justify-content-center">
            <div className="w-100 px-4 py-5" style={{ maxWidth: '480px' }}>
              <div className="card shadow-lg rounded-4 overflow-hidden">
                <div className="card-body p-5">
                  <h2 className="mb-4 text-center">
                    {isEdit ? 'Edit Flight' : 'Add New Flight'}
                  </h2>
                  {error && <div className="alert alert-danger">{error}</div>}
                  <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                      <div className="form-floating">
                        <input
                          id="flightNumber"
                          type="text"
                          className="form-control rounded-pill"
                          placeholder="Flight Number"
                          value={flightNumber}
                          onChange={e => setFlightNumber(e.target.value)}
                          required
                        />
                        <label htmlFor="flightNumber">Flight Number</label>
                      </div>
                    </div>

                    <div className="mb-3">
                      <div className="form-floating">
                        <input
                          id="flightName"
                          type="text"
                          className="form-control rounded-pill"
                          placeholder="Flight Name"
                          value={flightName}
                          onChange={e => setFlightName(e.target.value)}
                          required
                        />
                        <label htmlFor="flightName">Flight Name</label>
                      </div>
                    </div>

                    <div className="row g-3">
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="totalSeats"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Total Seats"
                            value={ 
                             totalSeats
                            }
                            onChange={e => setTotalSeats(e.target.value)}
                            disabled
                          />
                          <label htmlFor="totalSeats">Total Seats</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="checkinKg"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Check-in (kg)"
                            value={checkinKg}
                            onChange={e => setCheckinKg(e.target.value)}
                            required
                          />
                          <label htmlFor="checkinKg">Check-in (kg)</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="cabinKg"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Cabin (kg)"
                            value={cabinKg}
                            onChange={e => setCabinKg(e.target.value)}
                            required
                          />
                          <label htmlFor="cabinKg">Cabin (kg)</label>
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="economySeats"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Economy Seats"
                            value={economySeats}
                            onChange={e => setEconomySeats(e.target.value)}
                            disabled={isEdit}
                          />
                          <label htmlFor="economySeats">Economy Seats</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="businessSeats"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Business Seats"
                            value={businessSeats}
                            onChange={e => setBusinessSeats(e.target.value)}
                            disabled={isEdit}
                          />
                          <label htmlFor="businessSeats">Business Seats</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="premiumEconomySeats"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Premium Economy"
                            value={premiumEconomySeats}
                            onChange={e => setPremiumEconomySeats(e.target.value)}
                            disabled={isEdit}
                          />
                          <label htmlFor="premiumEconomySeats">Premium Economy</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="firstClassSeats"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="First Class Seats"
                            value={firstClassSeats}
                            onChange={e => setFirstClassSeats(e.target.value)}
                            disabled={isEdit}
                          />
                          <label htmlFor="firstClassSeats">First Class Seats</label>
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="btn btn-primary btn-lg w-100 rounded-pill shadow mt-4"
                    >
                      {isEdit ? 'Update Flight' : 'Create Flight'}
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
