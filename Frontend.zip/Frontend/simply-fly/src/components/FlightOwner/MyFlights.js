import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import FlightOwnerNavBar from './FlightOwnerNavBar';

export default function MyFlights() {
  const [flights, setFlights] = useState([]);
  const [selectedFlight, setSelectedFlight] = useState(null);
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    const fetchMyFlights = async () => {
      const token = localStorage.getItem('token');
      const res = await fetch(`${process.env.REACT_APP_BASE_URL}/api/flights`, {
        headers: { Authorization: 'Bearer ' + token }
      });
      const body = await res.json();
      setFlights(body.data.filter(f => f.owner?.userID === user.userID));
    };
    fetchMyFlights();
  }, [user.userID]);

  const handleDelete = async id => {
    if (!window.confirm('Delete this flight?')) return;
    const token = localStorage.getItem('token');
    await fetch(`${process.env.REACT_APP_BASE_URL}/api/flights/${id}`, {
      method: 'DELETE',
      headers: { Authorization: 'Bearer ' + token }
    });
    setFlights(prev => prev.filter(f => f.flightId !== id));
  };

  return (
    <>
      <FlightOwnerNavBar />

      <div className="container mt-5">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h2>My Flights</h2>
          <Link
            to="/flightForm"
            style={{
              padding: '10px 20px',
              background: 'green',
              color: 'white',
              borderRadius: '20px',
              textDecoration: 'none'
            }}
          >
            + Add Flight
          </Link>
        </div>

        {flights.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            {flights.map(f => (
              <div
                key={f.flightId}
                style={{
                  border: '1px solid #ddd',
                  borderRadius: '10px',
                  padding: '15px',
                  width: '100%',
                  boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer'
                }}
                onClick={() => setSelectedFlight(f)}
              >
                <div>
                  <h4 style={{ margin: '0 0 5px' }}>{f.flightNumber} - {f.flightName}</h4>
                  <p style={{ margin: 0 }}>Total Seats: {f.totalSeats}, Check-in: {f.checkinKg}kg, Cabin: {f.cabinKg}kg</p>
                </div>
                <div>
                  <span
                    onClick={e => { e.stopPropagation(); navigate(`/flightForm/${f.flightId}`); }}
                    style={{
                      marginRight: '15px', fontSize: '18px', cursor: 'pointer'
                    }}
                  >
                    ✏️
                  </span>
                  <span
                    onClick={e => { e.stopPropagation(); handleDelete(f.flightId); }}
                    style={{
                      fontSize: '18px', cursor: 'pointer'
                    }}
                  >
                    🗑️
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ textAlign: 'center', color: '#777' }}>No flights found.</p>
        )}
      </div>

      {/* Simple overlay modal for details */}
      {selectedFlight && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          background: 'rgba(0,0,0,0.6)', display: 'flex',
          justifyContent: 'center', alignItems: 'center', zIndex: 1000
        }}>
          <div style={{
            background: 'white', padding: '25px', borderRadius: '8px',
            minWidth: '300px', maxWidth: '500px'
          }}>
            <h3>Flight Details</h3>
            <p><strong>ID:</strong> {selectedFlight.flightId}</p>
            <p><strong>Number:</strong> {selectedFlight.flightNumber}</p>
            <p><strong>Name:</strong> {selectedFlight.flightName}</p>
            <p><strong>Total Seats:</strong> {selectedFlight.totalSeats}</p>
            <p><strong>Check-in Kg:</strong> {selectedFlight.checkinKg}</p>
            <p><strong>Cabin Kg:</strong> {selectedFlight.cabinKg}</p>
            <p><strong>Economy:</strong> {selectedFlight.economySeats}</p>
            <p><strong>Business:</strong> {selectedFlight.businessSeats}</p>
            <p><strong>Premium Economy:</strong> {selectedFlight.premiumEconomySeats}</p>
            <p><strong>First Class:</strong> {selectedFlight.firstClassSeats}</p>

            <div style={{ marginTop: '20px' }}>
              <button
                onClick={() => setSelectedFlight(null)}
                style={{ padding: '6px 12px', marginRight: '10px' }}
              >
                Close
              </button>
              <button
                onClick={() => {
                  navigate(`/flightForm/${selectedFlight.flightId}`);
                  setSelectedFlight(null);
                }}
                style={{
                  padding: '6px 12px', marginRight: '10px',
                  background: 'blue', color: 'white', border: 'none', borderRadius: '5px'
                }}
              >
                Edit
              </button>
              <button
                onClick={() => {
                  handleDelete(selectedFlight.flightId);
                  setSelectedFlight(null);
                }}
                style={{
                  background: 'red', color: 'white',
                  padding: '6px 12px', border: 'none', borderRadius: '5px'
                }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
