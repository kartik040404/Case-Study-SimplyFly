import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import FlightOwnerNavBar from './FlightOwnerNavBar';

export default function MyRoutes() {
  const [routes, setRoutes] = useState([]);
  const [error, setError] = useState('');
  const [selectedRoute, setSelectedRoute] = useState(null);
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    const fetchRoutes = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await fetch(
          `${process.env.REACT_APP_BASE_URL}/api/routes`,
          { headers: { Authorization: 'Bearer ' + token } }
        );
        const body = await res.json();
        setRoutes(
          body.data.filter(r => r.flight?.userID === user.userID)
        );
      } catch {
        setError('Failed to load routes.');
      }
    };
    fetchRoutes();
  }, [user.userID]);

  const handleDelete = async routeId => {
    if (!window.confirm('Delete this route?')) return;
    try {
      const token = localStorage.getItem('token');
      await fetch(
        `${process.env.REACT_APP_BASE_URL}/api/routes/${routeId}`,
        {
          method: 'DELETE',
          headers: { Authorization: 'Bearer ' + token }
        }
      );
      setRoutes(prev => prev.filter(r => r.routeId !== routeId));
    } catch {
      setError('Failed to delete route.');
    }
  };

  return (
    <>
      <FlightOwnerNavBar />

      <div className="container mt-5">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h2>My Routes</h2>
          <Link
            to="/routeForm"
            style={{
              padding: '10px 20px',
              background: 'green',
              color: 'white',
              borderRadius: '20px',
              textDecoration: 'none'
            }}
          >
            + Add Route
          </Link>
        </div>

        {error && <div style={{ color: 'red', marginBottom: '15px' }}>{error}</div>}

        {routes.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            {routes.map(r => (
              <div
                key={r.routeId}
                onClick={() => setSelectedRoute(r)}
                style={{
                  border: '1px solid #ddd',
                  borderRadius: '10px',
                  padding: '15px',
                  width: '100%',
                  boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer'
                }}
              >
                <div>
                  <h4 style={{ margin: '0 0 5px' }}>
                    {r.flight.flightNumber}: {r.origin} → {r.destination}
                  </h4>
                  <p style={{ margin: 0 }}>
                    Dep: {new Date(r.departureTs).toLocaleString()} | Arr: {new Date(r.arrivalTs).toLocaleString()}
                  </p>
                </div>
                <div>
                  <span
                    onClick={e => { e.stopPropagation(); navigate(`/routeForm/${r.routeId}`); }}
                    style={{
                      marginRight: '15px', fontSize: '18px', cursor: 'pointer'
                    }}
                  >
                    ✏️
                  </span>
                  <span
                    onClick={e => { e.stopPropagation(); handleDelete(r.routeId); }}
                    style={{
                      fontSize: '18px', cursor: 'pointer'
                    }}
                  >
                    🗑️
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ textAlign: 'center', color: '#777' }}>No routes found.</p>
        )}
      </div>

      {/* Details Modal */}
      {selectedRoute && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          background: 'rgba(0,0,0,0.6)', display: 'flex',
          justifyContent: 'center', alignItems: 'center', zIndex: 1000
        }}>
          <div style={{
            background: 'white', padding: '25px', borderRadius: '8px',
            minWidth: '300px', maxWidth: '500px'
          }}>
            <h3>Route Details</h3>
            <p><strong>ID:</strong> {selectedRoute.routeId}</p>
            <p><strong>Flight:</strong> {selectedRoute.flight.flightNumber} - {selectedRoute.flight.flightName}</p>
            <p><strong>Origin:</strong> {selectedRoute.origin}</p>
            <p><strong>Destination:</strong> {selectedRoute.destination}</p>
            <p><strong>Departure:</strong> {new Date(selectedRoute.departureTs).toLocaleString()}</p>
            <p><strong>Arrival:</strong> {new Date(selectedRoute.arrivalTs).toLocaleString()}</p>
            <p><strong>Economy Fare:</strong> ₹{selectedRoute.economyFare}</p>
            <p><strong>Business Fare:</strong> ₹{selectedRoute.businessFare}</p>
            <p><strong>Premium Economy Fare:</strong> ₹{selectedRoute.premiumEconomyFare}</p>
            <p><strong>First Class Fare:</strong> ₹{selectedRoute.firstClassFare}</p>

            <div style={{ marginTop: '20px' }}>
              <button
                onClick={() => setSelectedRoute(null)}
                style={{ padding: '6px 12px', marginRight: '10px' }}
              >
                Close
              </button>
              <button
                onClick={() => {
                  navigate(`/routeForm/${selectedRoute.routeId}`);
                  setSelectedRoute(null);
                }}
                style={{
                  padding: '6px 12px', marginRight: '10px',
                  background: 'blue', color: 'white', border: 'none', borderRadius: '5px'
                }}
              >
                Edit
              </button>
              <button
                onClick={() => {
                  handleDelete(selectedRoute.routeId);
                  setSelectedRoute(null);
                }}
                style={{
                  background: 'red', color: 'white',
                  padding: '6px 12px', border: 'none', borderRadius: '5px'
                }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
