// src/components/PassengerDashboard.jsx
import React from 'react';
import PassengerNavBar from './PassengerNavBar';
import SearchBar from '../SearchBar';
import bgImage from '../assets/images/passengerDashboard2.jpg'; // your attached image

export default function PassengerDashboard() {

  return (
    <div
      className="position-relative"
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        minHeight: '100vh'
      }}
    >
      <div
        className="position-absolute top-0 start-0 w-100 h-100"
        style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
      />

      <div className="position-relative">
        <PassengerNavBar />

        <div className="container position-relative text-white py-5">
          {/* Hero text */}
          <div className="text-center mb-5">
            <h1 className="display-4 fw-bold">Welcome Back!</h1>
            <p className="lead">
              Search flights, view your bookings, and manage your profile.
            </p>
          </div>

          <div className="row justify-content-center mb-5">
            <div className="col-md-8">
              <SearchBar />
            </div>
          </div>

       
        </div>
      </div>
    </div>
  );
}
