// src/components/Passenger/BookingDetails.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate }       from 'react-router-dom';
import PassengerNavBar                   from './PassengerNavBar';

export default function BookingDetails() {
  const { bookingId } = useParams();
  const [booking, setBooking] = useState(null);
  const [history, setHistory] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDetails = async () => {
      const token = localStorage.getItem('token');

      // 1) booking itself
      const res1  = await fetch(
        `${process.env.REACT_APP_BASE_URL}/api/bookings/${bookingId}`,
        { headers: { Authorization: 'Bearer ' + token } }
      );
      const body1 = await res1.json();
      setBooking(body1.data);

      // 2) history entries
      const res2  = await fetch(
        `${process.env.REACT_APP_BASE_URL}/api/bookings/history/${bookingId}`,
        { headers: { Authorization: 'Bearer ' + token } }
      );
      const body2 = await res2.json();
      setHistory(body2.data || []);
    };
    fetchDetails();
  }, [bookingId]);

  if (!booking) return <p className="text-center mt-5">Loading…</p>;

  return (
    <>
      <PassengerNavBar />

      <div className="container mt-4">
        <div className="card shadow rounded-3">
          <div className="card-header bg-primary text-white">
            <h5 className="mb-0">Booking #{booking.bookingId}</h5>
          </div>
          <div className="card-body">
            <dl className="row">
              <dt className="col-sm-3">Route</dt>
              <dd className="col-sm-9">
                {booking.route.origin} → {booking.route.destination}
              </dd>

              <dt className="col-sm-3">Flight</dt>
              <dd className="col-sm-9">
                {booking.route.flight.flightNumber} ({booking.route.flight.flightName})
              </dd>

              <dt className="col-sm-3">Seats</dt>
              <dd className="col-sm-9">
                {booking.bookingSeats
                  .map(bs => bs.seat.seatNumber)
                  .join(', ')}
              </dd>

              <dt className="col-sm-3">Total Amount</dt>
              <dd className="col-sm-9">
                ₹{booking.totalAmount.toFixed(2)}
              </dd>

              <dt className="col-sm-3">Status</dt>
              <dd className="col-sm-9">{booking.status}</dd>
            </dl>

            <h6 className="mt-4">History</h6>
            {history.length === 0 ? (
              <p className="text-muted">No history available.</p>
            ) : (
              <ul className="list-group mb-3">
                {history.map(h => (
                  <li key={h.historyId} className="list-group-item">
                    <strong>{h.action}</strong> on{' '}
                    {new Date(h.actionDate).toLocaleString()}
                  </li>
                ))}
              </ul>
            )}

            <div className="d-flex justify-content-between">
              <button
                className="btn btn-secondary"
                onClick={() => navigate('/passenger/dashboard/bookings')}
              >
                ← Back to My Bookings
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
