import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PassengerNavBar from './PassengerNavBar';

const BookingsList = () => {
  const [bookings, setBookings] = useState([]);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBookings = async () => {
      const token = localStorage.getItem('token');
      const user = JSON.parse(localStorage.getItem('user'));
      const res = await fetch(
        `${process.env.REACT_APP_BASE_URL}/api/bookings/api/users/${user.userID}/bookings`,
        { headers: { Authorization: 'Bearer ' + token } }
      );
      const body = await res.json();
      setBookings(body.data || []);
    };
    fetchBookings();
  }, []);

  const handleCancelBooking = async (booking) => {
    const token = localStorage.getItem('token');
    const updatedBooking = { ...booking, status: 'CANCELLED' };

    const res = await fetch(
      `${process.env.REACT_APP_BASE_URL}/api/bookings/cancel/${booking.bookingId}`,
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + token
        },
        body: JSON.stringify(updatedBooking)
      }
    );

    if (res.ok) {
      setBookings(prev =>
        prev.map(b =>
          b.bookingId === booking.bookingId
            ? { ...b, status: 'CANCELLED' }
            : b
        )
      );
      setSelectedBooking(null);
      alert('Booking cancelled successfully.');
    } else {
      alert('Failed to cancel booking.');
    }
  };

  return (
    <>
      <PassengerNavBar />

      <div className="container my-5">
        <h2 className="mb-4">My Bookings</h2>

        {bookings.length === 0 ? (
          <p>No bookings yet.</p>
        ) : (
          <div className="row g-4">
            {bookings.map(b => (
              <div key={b.bookingId} className="col-md-6 col-lg-4">
                <div className="card shadow-sm border-0 rounded-4 h-100">
                  <div className="card-body">
                    <h5 className="card-title fw-bold">Booking #{b.bookingId}</h5>
                    <h6 className="card-subtitle mb-2 text-muted">{b.origin} ➝ {b.destination}</h6>
                    <p className="card-text mb-1"><strong>Amount:</strong> ₹{b.totalAmount}</p>
                    <p className="card-text mb-1">
                      <strong>Status:</strong>{' '}
                      <span className={`badge rounded-pill bg-${b.status === 'CANCELLED' ? 'danger' : 'success'}`}>
                        {b.status}
                      </span>
                    </p>
                  </div>
                  <div className="card-footer bg-transparent border-top-0 text-end">
                    <button
                      className="btn btn-sm btn-outline-primary rounded-pill"
                      onClick={() => setSelectedBooking(b)}
                    >
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal */}
      {selectedBooking && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          background: 'rgba(0,0,0,0.5)', display: 'flex',
          justifyContent: 'center', alignItems: 'center', zIndex: 1000
        }}>
          <div style={{
            background: 'white', padding: '25px', borderRadius: '10px',
            minWidth: '320px', maxWidth: '500px'
          }}>
            <h4 className="mb-3">Booking Details</h4>
            <p><strong>Booking ID:</strong> {selectedBooking.bookingId}</p>
            <p><strong>Route:</strong> {selectedBooking.origin} ➝ {selectedBooking.destination}</p>
            <p><strong>Total Amount:</strong> ₹{selectedBooking.totalAmount}</p>
            <p><strong>Status:</strong> {selectedBooking.status}</p>
            {selectedBooking.departureTime && (
              <p><strong>Departure:</strong> {selectedBooking.departureTime}</p>
            )}
            {selectedBooking.arrivalTime && (
              <p><strong>Arrival:</strong> {selectedBooking.arrivalTime}</p>
            )}
            {selectedBooking.seats && (
              <p><strong>Seats:</strong> {selectedBooking.seats.join(', ')}</p>
            )}

            <div className="d-flex justify-content-end gap-2 mt-4">
              <button className="btn btn-outline-secondary" onClick={() => setSelectedBooking(null)}>
                Close
              </button>
              {selectedBooking.status === 'BOOKED' && (
                <button
                  className="btn btn-danger"
                  onClick={() => handleCancelBooking(selectedBooking)}
                >
                  Cancel Booking
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default BookingsList;
