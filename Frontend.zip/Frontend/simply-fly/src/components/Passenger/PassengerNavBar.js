// src/components/PassengerNavBar.jsx
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function PassengerNavBar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login', { replace: true });
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-black shadow-sm">
      <div className="container">
        <Link className="navbar-brand fw-bold text-white" to="/passenger/dashboard">
          SimplyFly
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#passengerNavbar"
          aria-controls="passengerNavbar"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>

        <div className="collapse navbar-collapse" id="passengerNavbar">
          <ul className="navbar-nav ms-auto align-items-center">
            <li className="nav-item mx-2">
              <Link className="nav-link text-white" to="/passenger/dashboard">
                Search
              </Link>
            </li>
            <li className="nav-item mx-2">
              <Link className="nav-link text-white" to="/passenger/dashboard/bookings">
                Bookings
              </Link>
            </li>
            <li className="nav-item mx-2">

              <Link className="nav-link text-white" to="/passenger/dashboard/history">History</Link>
            </li>

            <li className="nav-item mx-2">
              <Link className="nav-link text-white" to="/passenger/dashboard/profile">
                Profile
              </Link>
            </li>
            <li className="nav-item mx-2">
              <button
                className="btn btn-outline-black rounded-pill text-white"
                onClick={handleLogout}
              >
                Logout
              </button>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
