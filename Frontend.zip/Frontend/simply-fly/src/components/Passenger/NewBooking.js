// src/components/Passenger/NewBooking.js
import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const stripePromise = loadStripe(process.env.REACT_APP_PUBLISHABLE_KEY);
const API = process.env.REACT_APP_BASE_URL;

export default function NewBooking() {
  const navigate = useNavigate();
  const { search } = useLocation();
  const params   = new URLSearchParams(search);
  const routeId  = params.get('routeId');
  const seatsStr = params.get('seats') || '';
  const seatIds  = seatsStr.split(',').map(id => parseInt(id, 10));

  const [route, setRoute]     = useState(null);
  const [seats, setSeats]     = useState([]);
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const total = seats.reduce((sum, s) => sum + (s.fare || 0), 0);

  useEffect(() => {
    (async () => {
      try {
        const token = localStorage.getItem('token');
        const [rRes, sRes] = await Promise.all([
          fetch(`${API}/api/routes/${routeId}`, {
            headers: { Authorization: 'Bearer ' + token }
          }),
          fetch(`${API}/api/seats/routes/${routeId}/seats`, {
            headers: { Authorization: 'Bearer ' + token }
          })
        ]);
        const rBody = await rRes.json();
        setRoute(rBody.data);

        const sBody = await sRes.json();
        setSeats(sBody.data.filter(s => seatIds.includes(s.seatId)));
      } catch {
        setError('Failed to load booking info.');
      }
    })();
  }, [routeId, seatsStr]);

  if (!route) return <p className="text-center mt-5">Loading…</p>;

  const handlePay = async () => {
    setLoading(true);
    setError('');
    try {
      const token = localStorage.getItem('token');
      const user  = JSON.parse(localStorage.getItem('user'));

      const bookingPayload = {
        user:        { userID: user.userID },
        route:       { routeId: parseInt(routeId, 10) },
        totalAmount: total,
        bookedAt:    new Date().toISOString(),
        status:      'BOOKED'
      };
      const bRes  = await fetch(`${API}/api/bookings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization:  'Bearer ' + token
        },
        body: JSON.stringify(bookingPayload)
      });
      const bBody = await bRes.json();
      if (!bBody.success) throw new Error(bBody.message || 'Booking failed');
      const bookingId = bBody.data.bookingId;

      const sessRes = await fetch(
        `${API}/api/bookings/${bookingId}/createStripeSession`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization:  'Bearer ' + token
          }
        }
      );
      const { sessionId } = await sessRes.json();

      const stripe = await stripePromise;
      await stripe.redirectToCheckout({ sessionId });

    } catch (e) {
      console.error(e);
      setError(e.message || 'Payment initialization failed.');
      setLoading(false);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Confirm & Pay</h2>
      {error && <div className="alert alert-danger">{error}</div>}

      <dl className="row">
        <dt className="col-sm-4">Route</dt>
        <dd className="col-sm-8">
          {route.origin} → {route.destination}
        </dd>

        <dt className="col-sm-4">Departure</dt>
        <dd className="col-sm-8">
          {new Date(route.departureTs).toLocaleString()}
        </dd>

        <dt className="col-sm-4">Arrival</dt>
        <dd className="col-sm-8">
          {new Date(route.arrivalTs).toLocaleString()}
        </dd>

        <dt className="col-sm-4">Flight</dt>
        <dd className="col-sm-8">
          {route.flightNumber} ({route.flightName})
        </dd>

        <dt className="col-sm-4">Seats & Fares</dt>
        <dd className="col-sm-8">
          <ul className="list-unstyled mb-0">
            {seats.map(s => (
              <li key={s.seatId}>
                {s.seatNumber} – ₹{s.fare.toFixed(2)}
              </li>
            ))}
          </ul>
        </dd>

        <dt className="col-sm-4">Total Amount</dt>
        <dd className="col-sm-8 fw-bold">
          ₹{total.toFixed(2)}
        </dd>
      </dl>

      <div className="d-flex mb-4">
        <Link
          to={`/passenger/dashboard/seats/${routeId}`}
          className="btn btn-secondary me-2"
        >
          Modify Seats
        </Link>
        <button
          className="btn btn-primary"
          onClick={handlePay}
          disabled={loading}
        >
          {loading && (
            <span
              className="spinner-border spinner-border-sm me-2"
              role="status"
            />
          )}
          Pay ₹{total.toFixed(2)}
        </button>
      </div>

      <ToastContainer position="top-center" />
    </div>
  );
}
