import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import PassengerNavBar from './PassengerNavBar';

const classMeta = {
  ECONOMY: { label: 'Economy',bg: 'bg-success bg-opacity-25', border: 'border-success' },
  BUSINESS:{ label: 'Business', bg: 'bg-warning bg-opacity-25', border: 'border-warning' },
  PREMIUM_ECONOMY: { label: 'Premium Economy', bg: 'bg-info bg-opacity-25', border: 'border-info' },
  FIRST_CLASS: { label: 'First Class',bg: 'bg-danger bg-opacity-25', border: 'border-danger' },
};

const SeatSelection = () => {
  const { routeId } = useParams();
  const [seats, setSeats]       = useState([]);
  const [selected, setSelected] = useState(new Set());
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      const token = localStorage.getItem('token');
      const res   = await fetch(
        `${process.env.REACT_APP_BASE_URL}/api/seats/routes/${routeId}/seats`,
        { headers: { Authorization: 'Bearer ' + token }}
      );
      if (res.ok) {
        const body = await res.json();
        setSeats(body.data);
      }
    })();
  }, [routeId]);

  const toggleSeat = id => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const totalFare = [...selected].reduce((sum, id) => {
    const s = seats.find(x => x.seatId === id);
    return sum + (s?.fare || 0);
  }, 0);

  const handleConfirm = () =>
    navigate(`/passenger/dashboard/newBooking?routeId=${routeId}&seats=${[...selected].join(',')}`);

  const grouped = seats.reduce((acc, s) => {
    (acc[s.classType] ||= []).push(s);
    return acc;
  }, {});

  return (
    <>
     <PassengerNavBar/>

      <div className="container">
        <h2 className="mb-3">Select Seats for Route {routeId}</h2>

        <div className="d-flex flex-wrap mb-4">
          {Object.entries(classMeta).map(([key, { label, bg, border }]) => (
            <div key={key} className="d-flex align-items-center me-3 mb-2">
              <div
                className={`${bg} ${border} rounded me-2`}
                style={{ width: '20px', height: '20px' }}
              />
              <small>{label}</small>
            </div>
          ))}
        </div>

        {/* Sections */}
        {Object.entries(grouped).map(([cls, list]) => {
          const { label, bg, border } = classMeta[cls] || {};
          return (
            <div key={cls} className="card mb-4">
              <div className="card-header">
                <strong>{label}</strong> — ${list[0]?.fare.toFixed(2)} each
              </div>
              <div className="card-body">
                <div className="d-flex flex-wrap">
                  {list.map(s => {
                    const isSel = selected.has(s.seatId);
                    return (
                      <div
                        key={s.seatId}
                        onClick={() => toggleSeat(s.seatId)}
                        title={`${label} — $${s.fare.toFixed(2)}`}
                        className={`
                          m-1 p-2 border ${border} rounded text-center
                          ${bg} ${isSel ? 'bg-opacity-100 text-white fw-bold' : 'bg-opacity-25'}
                        `}
                        style={{ width: '60px', cursor: 'pointer' }}
                      >
                        {s.seatNumber}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}

        {selected.size > 0 && (
          <div className="mb-3">
            <strong>
              {selected.size} seat{selected.size>1?'s':''} selected &nbsp;
              Total: ${totalFare.toFixed(2)}
            </strong>
          </div>
        )}
        <button
          className="btn btn-success"
          onClick={handleConfirm}
          disabled={!selected.size}
        >
          Confirm
        </button>
      </div>
    </>
  );
};

export default SeatSelection;
