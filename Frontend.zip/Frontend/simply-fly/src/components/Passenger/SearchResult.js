import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import SearchBar from '../SearchBar';
import PassengerNavBar from './PassengerNavBar';

const SearchResults = () => {
  const [routes, setRoutes] = useState([]);
  const [allRoutes, setAllRoutes] = useState([]);
  const location = useLocation();
  const navigate = useNavigate();

  const params = new URLSearchParams(location.search);
  const origin = params.get('origin') || '';
  const destination = params.get('destination') || '';
  const date = params.get('date') || '';

  useEffect(() => {
    const fetchAllRoutes = async () => {
      const token = localStorage.getItem('token');
      const res = await fetch(`${process.env.REACT_APP_BASE_URL}/api/routes`, {
        headers: { Authorization: 'Bearer ' + token }
      });
      const body = await res.json();
      setAllRoutes(body.data || []);
    };
    fetchAllRoutes();
  }, []);

  // Filter search results
  useEffect(() => {
    if (!origin || !destination || !date || !allRoutes.length) return;

    const filtered = allRoutes.filter(
      r =>
        r.origin.toLowerCase().includes(origin.toLowerCase()) &&
        r.destination.toLowerCase().includes(destination.toLowerCase()) &&
        r.departureTs.startsWith(date)
    );
    setRoutes(filtered);
  }, [origin, destination, date, allRoutes]);

  return (
    <>
      <PassengerNavBar />

      <div className="container">
        <SearchBar allRoutes={allRoutes} />

        {(origin && destination && date) && (
          <>
            <h2 className="mb-4">Search Results</h2>
            {routes.length === 0 ? (
              <p>No routes found for this query.</p>
            ) : (
              <div className="row g-4 mb-5">
                {routes.map(r => (
                  <div className="col-md-6 col-lg-4" key={r.routeId}>
                    <div
                      className="card shadow-sm rounded-4 h-100 border-0"
                      style={{ cursor: 'pointer' }}
                      onClick={() => navigate(`/passenger/dashboard/seats/${r.routeId}`)}
                    >
                      <div className="card-body">
                        <h5 className="card-title fw-bold">
                          {r.origin} ➝ {r.destination}
                        </h5>
                        <p className="card-text mb-1 text-muted">
                          Flight: {r.flightNumber} ({r.flightName})
                        </p>
                        <p className="card-text">
                          Departure: <strong>{new Date(r.departureTs).toLocaleString()}</strong>
                        </p>
                      </div>
                      <div className="card-footer bg-transparent border-top-0">
                        <button className="btn btn-sm btn-outline-primary rounded-pill">
                          View Seats
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* All Routes Section */}
        <h2 className="mt-5 mb-4">All Available Routes</h2>
        {allRoutes.length === 0 ? (
          <p>Loading routes...</p>
        ) : (
          <div className="row g-4 pb-5">
            {allRoutes.map(r => (
              <div className="col-md-6 col-lg-4" key={r.routeId}>
                <div
                  className="card shadow-sm rounded-4 h-100 border-0"
                  style={{ cursor: 'pointer' }}
                  onClick={() => navigate(`/passenger/dashboard/seats/${r.routeId}`)}
                >
                  <div className="card-body">
                    <h5 className="card-title fw-bold">
                      {r.origin} ➝ {r.destination}
                    </h5>
                    <p className="card-text mb-1 text-muted">
                      Flight: {r.flightNumber} ({r.flightName})
                    </p>
                    <p className="card-text">
                      Departure: <strong>{new Date(r.departureTs).toLocaleString()}</strong>
                    </p>
                  </div>
                  <div className="card-footer bg-transparent border-top-0">
                    <button className="btn btn-sm btn-outline-primary rounded-pill">
                      View Seats
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
};

export default SearchResults;
