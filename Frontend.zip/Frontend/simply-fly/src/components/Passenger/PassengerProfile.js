// src/components/Admin/AdminProfile.js
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PassengerNavBar from '../Passenger/PassengerNavBar';

export default function PassengerProfile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [editUser, setEditUser] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  
  useEffect(() => {
    const stored = localStorage.getItem('user');
    const userData = stored ? JSON.parse(stored) : null;
    setUser(userData);
    setEditUser(userData || {});
  }, []);

  useEffect(() => {
    if (!user) {
      navigate('/passenger/dashboard/profile', { replace: true });
    }
  }, [user, navigate]);

  const handleInputChange = (field, value) => {
    setEditUser(prev => ({
      ...prev,
      [field]: value
    }));
  };

 const handleUpdateProfile = async () => {
  setIsLoading(true);
  try {
    const token = localStorage.getItem('token'); 
console.log('Updating profile with token:',user.userID);
    const response = await fetch(`${process.env.REACT_APP_BASE_URL}/api/users/${user.userID}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}` 
      },
      body: JSON.stringify(editUser)
    });

    const result = await response.json();
console.log('Profile update result:', result.success);
    if (result.success) {
      setUser(result.data);
      localStorage.setItem('user', JSON.stringify(result.data));

      // Close modal safely
      const modalEl = document.getElementById('editModal');
      const modal = window.bootstrap.Modal.getInstance(modalEl) || new window.bootstrap.Modal(modalEl);
      modal.hide();

      showToast('Profile updated successfully!', 'success');
    } else {
      showToast('Failed to update profile: ' + result.message, 'error');
    }
  } catch (error) {
    console.error('Error updating profile:', error);
    showToast('Error updating profile. Please try again.', 'error');
  } finally {
    setIsLoading(false);
  }
};


  const showToast = (message, type) => {
    const toastContainer = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
      <div class="d-flex">
        <div class="toast-body">${message}</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    `;
    toastContainer.appendChild(toast);
    const bsToast = new window.bootstrap.Toast(toast);
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', () => {
      toast.remove();
    });
  };

  if (!user) return null;

  const avatarUrl = user.avatarUrl || 
    `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=6f42c1&color=fff&size=256`;

  return (
    <>
      <PassengerNavBar />
      
      {/* Toast Container */}
      <div className="position-fixed top-0 end-0 p-3" style={{ zIndex: 1055 }} id="toastContainer"></div>

      <div className="position-relative" style={{ minHeight: '100vh' }}>
        {/* Cover / hero area with background image */}
        <div
          className="w-100 position-relative"
          style={{
            height: '300px',
            backgroundImage: 'url(https://images.unsplash.com/photo-1436491865332-7a61a109cc05?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2074&q=80)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            overflow: 'hidden'
          }}
        >
          {/* Dark overlay for better text readability */}
          <div className="position-absolute top-0 start-0 w-100 h-100" style={{ background: 'rgba(0,0,0,0.4)' }}></div>


          {/* Edit Button */}
          <div className="position-absolute top-0 end-0 m-4">
            <button 
              type="button" 
              className="btn btn-light btn-sm shadow-sm"
              data-bs-toggle="modal" 
              data-bs-target="#editModal"
            >
              <i className="fas fa-edit me-2"></i>Edit Profile
            </button>
          </div>
        </div>

        {/* Main Content Container */}
        <div className="container" style={{ marginTop: '-150px' }}>
          {/* Profile Card */}
          <div className="row justify-content-center">
            <div className="col-12 col-lg-10">
              <div className="card shadow-lg border-0">
                <div className="card-body p-5">
                  {/* Avatar Section */}
                  <div className="text-center mb-4">
                    <div className="position-relative d-inline-block">
                      <img
                        src={avatarUrl}
                        alt="Profile"
                        className="rounded-circle border border-white shadow-lg"
                        style={{
                          width: '150px',
                          height: '150px',
                          objectFit: 'cover',
                          borderWidth: '4px !important'
                        }}
                      />
                    </div>
                    <h2 className="mt-3 mb-1 fw-bold text-dark">{user.name}</h2>
                    <p className="text-muted fs-5 mb-3">{user.email}</p>
                    <span className="badge bg-primary fs-6 px-3 py-2">
                      <i className="fas fa-shield-alt me-2"></i>{user.role}
                    </span>
                  </div>

                  {/* Profile Information Cards */}
                  <div className="row g-4 mt-4">
                    {/* Personal Information */}
                    <div className="col-md-6">
                      <div className="card h-100 bg-light border-0 shadow-sm">
                        <div className="card-body">
                          <h5 className="card-title text-primary mb-3">
                            <i className="fas fa-user me-2"></i>Personal Information
                          </h5>
                          <div className="row g-3">
                            <div className="col-12">
                              <div className="d-flex justify-content-between">
                                <span className="text-muted">User ID:</span>
                                <span className="fw-medium">{user.userID}</span>
                              </div>
                            </div>
                            <div className="col-12">
                              <div className="d-flex justify-content-between">
                                <span className="text-muted">Gender:</span>
                                <span className="fw-medium">{user.gender}</span>
                              </div>
                            </div>
                            <div className="col-12">
                              <div className="d-flex justify-content-between">
                                <span className="text-muted">Role:</span>
                                <span className="fw-medium">{user.role}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Contact Information */}
                    <div className="col-md-6">
                      <div className="card h-100 bg-light border-0 shadow-sm">
                        <div className="card-body">
                          <h5 className="card-title text-success mb-3">
                            <i className="fas fa-phone me-2"></i>Contact Details
                          </h5>
                          <div className="row g-3">
                            <div className="col-12">
                              <div className="d-flex justify-content-between">
                                <span className="text-muted">Phone:</span>
                                <span className="fw-medium">{user.contactNumber}</span>
                              </div>
                            </div>
                            <div className="col-12">
                              <div className="d-flex justify-content-between">
                                <span className="text-muted">Email:</span>
                                <span className="fw-medium">{user.email}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Address Information */}
                    <div className="col-md-6">
                      <div className="card h-100 bg-light border-0 shadow-sm">
                        <div className="card-body">
                          <h5 className="card-title text-warning mb-3">
                            <i className="fas fa-map-marker-alt me-2"></i>Address
                          </h5>
                          <p className="mb-0 fw-medium">{user.address}</p>
                        </div>
                      </div>
                    </div>

                    {/* Account Information */}
                    <div className="col-md-6">
                      <div className="card h-100 bg-light border-0 shadow-sm">
                        <div className="card-body">
                          <h5 className="card-title text-info mb-3">
                            <i className="fas fa-calendar-alt me-2"></i>Account Created
                          </h5>
                          <div className="row g-3">
                            <div className="col-12">
                              <div className="d-flex justify-content-between">
                                <span className="text-muted">Date:</span>
                                <span className="fw-medium">{new Date(user.createdAt).toLocaleDateString()}</span>
                              </div>
                            </div>
                            <div className="col-12">
                              <div className="d-flex justify-content-between">
                                <span className="text-muted">Time:</span>
                                <span className="fw-medium">{new Date(user.createdAt).toLocaleTimeString()}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      <div className="modal fade" id="editModal" tabIndex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header bg-primary text-white">
              <h5 className="modal-title" id="editModalLabel">
                <i className="fas fa-edit me-2"></i>Edit Profile
              </h5>
              <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <form>
                <div className="row g-3">
                  <div className="col-md-6">
                    <label htmlFor="name" className="form-label">Full Name</label>
                    <input
                      type="text"
                      className="form-control"
                      id="name"
                      value={editUser.name || ''}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                    />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="email" className="form-label">Email</label>
                    <input
                      type="email"
                      className="form-control"
                      id="email"
                      value={editUser.email || ''}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                    />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="gender" className="form-label">Gender</label>
                    <select
                      className="form-select"
                      id="gender"
                      value={editUser.gender || ''}
                      onChange={(e) => handleInputChange('gender', e.target.value)}
                    >
                      <option value="">Select Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="contactNumber" className="form-label">Contact Number</label>
                    <input
                      type="tel"
                      className="form-control"
                      id="contactNumber"
                      value={editUser.contactNumber || ''}
                      onChange={(e) => handleInputChange('contactNumber', e.target.value)}
                    />
                  </div>
                  <div className="col-12">
                    <label htmlFor="address" className="form-label">Address</label>
                    <textarea
                      className="form-control"
                      id="address"
                      rows="3"
                      value={editUser.address || ''}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                    ></textarea>
                  </div>
                </div>
              </form>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                <i className="fas fa-times me-2"></i>Cancel
              </button>
              <button 
                type="button" 
                className="btn btn-primary"
                onClick={handleUpdateProfile}
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    Updating...
                  </>
                ) : (
                  <>
                    <i className="fas fa-save me-2"></i>Save Changes
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}