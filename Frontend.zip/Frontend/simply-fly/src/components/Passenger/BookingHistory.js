import React, { useState, useEffect } from 'react';
import PassengerNavBar from './PassengerNavBar';

const BookingHistory = () => {
  const [history, setHistory] = useState([]);
  const [selectedBooking, setSelectedBooking] = useState(null);

  useEffect(() => {
    const fetchBookingHistory = async () => {
      const token = localStorage.getItem('token');
      const user = JSON.parse(localStorage.getItem('user'));
      const res = await fetch(
        `${process.env.REACT_APP_BASE_URL}/api/bookings/history/${user.userID}`,
        { headers: { Authorization: 'Bearer ' + token } }
      );
      const body = await res.json();
      const all = body.data || [];

      const today = new Date().toISOString().split('T')[0];
  console.log('Today:', all);

const pastOrCancelled = all.filter(b => {
  const depTime = b.departureTime ? new Date(b.departureTime) : null;
  console.log(`Booking ID: ${b.bookingId}, Departure: ${depTime}, Today: ${today}, Status: ${b.status}`);
  
  return b.status === 'CANCELLED' || (depTime && depTime < today);
});


      setHistory(pastOrCancelled);
    };
    fetchBookingHistory();
  }, []);

  return (
    <>
      <PassengerNavBar />

      <div className="container my-5">
        <h2 className="mb-4">Booking History</h2>

        {history.length === 0 ? (
          <p>No past or cancelled bookings found.</p>
        ) : (
          <div className="row g-4">
            {history.map(b => (
              <div key={b.bookingId} className="col-md-6 col-lg-4">
                <div
                  className="card shadow-sm border-0 rounded-4 h-100"
                  style={{ cursor: 'pointer' }}
                  onClick={() => setSelectedBooking(b)}
                >
                  <div className="card-body">
                    <h5 className="card-title fw-bold">Booking #{b.bookingId}</h5>
                    <h6 className="card-subtitle mb-2 text-muted">{b.origin} ➝ {b.destination}</h6>
                    <p className="card-text mb-1"><strong>Amount:</strong> ₹{b.totalAmount}</p>
                    <p className="card-text mb-1">
                      <strong>Status:</strong>{' '}
                      <span className={`badge rounded-pill bg-${b.status === 'CANCELLED' ? 'danger' : 'secondary'}`}>
                        {b.status}
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedBooking && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          background: 'rgba(0,0,0,0.5)', display: 'flex',
          justifyContent: 'center', alignItems: 'center', zIndex: 1000
        }}>
          <div style={{
            background: 'white', padding: '25px', borderRadius: '10px',
            minWidth: '320px', maxWidth: '500px'
          }}>
            <h4 className="mb-3">Booking Details</h4>
            <p><strong>Booking ID:</strong> {selectedBooking.bookingId}</p>
            <p><strong>Route:</strong> {selectedBooking.origin} ➝ {selectedBooking.destination}</p>
            <p><strong>Total Amount:</strong> ₹{selectedBooking.totalAmount}</p>
            <p><strong>Status:</strong> {selectedBooking.status}</p>
            {selectedBooking.departureTime && (
              <p><strong>Departure:</strong> {selectedBooking.departureTime}</p>
            )}
            {selectedBooking.arrivalTime && (
              <p><strong>Arrival:</strong> {selectedBooking.arrivalTime}</p>
            )}
            {selectedBooking.seats && (
              <p><strong>Seats:</strong> {selectedBooking.seats.join(', ')}</p>
            )}

            <div className="d-flex justify-content-end mt-4">
              <button className="btn btn-outline-secondary" onClick={() => setSelectedBooking(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default BookingHistory;
