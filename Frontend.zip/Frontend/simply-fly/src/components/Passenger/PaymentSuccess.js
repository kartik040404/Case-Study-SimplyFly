// src/components/Passenger/PaymentSuccess.js
import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ToastContainer, toast }    from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const API = process.env.REACT_APP_BASE_URL;

export default function PaymentSuccess() {
  const navigate = useNavigate();
  const { search } = useLocation();
  const params    = new URLSearchParams(search);
  const bookingId = params.get('bookingId');

  useEffect(() => {
    (async () => {
      try {
        const token = localStorage.getItem('token');
        const bRes = await fetch(`${API}/api/bookings/${bookingId}`, {
          headers: { Authorization: 'Bearer ' + token }
        });
        const bBody = await bRes.json();
        const amount = bBody.data.totalAmount;

        await fetch(
          `${API}/api/bookings/${bookingId}/payments`,
          {
            method: 'POST',
            headers: {
              'Content-Type':'application/json',
              Authorization:'Bearer '+token
            },
            body: JSON.stringify({
              paymentMethod: 'CARD',
              paymentStatus: 'PAID',
              amountPaid: amount,
              paymentDate: new Date().toISOString()
            })
          }
        );

        toast.success(' Payment successful!');
        setTimeout(() => navigate('/passenger/dashboard/bookings'), 1500);

      } catch (e) {
        console.error(e);
        toast.error('Failed to record payment.');
      }
    })();
  }, [bookingId, navigate]);

  return (
    <div className="container text-center mt-5">
      <p>Processing your payment…</p>
      <ToastContainer position="top-center" />
    </div>
  );
}
