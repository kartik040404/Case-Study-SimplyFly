// src/components/FlightsList.jsx
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaEdit, FaTrash } from 'react-icons/fa';
import NavBar from '../NavBar';
  import { toast } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css';
export default function FlightsList() {
  const [flights, setFlights] = useState([]);
  const [selectedFlight, setSelectedFlight] = useState(null);

  const fetchFlights = async () => {
    const token = localStorage.getItem('token');
    const res = await fetch(`${process.env.REACT_APP_BASE_URL}/api/flights`, {
      headers: { Authorization: 'Bearer ' + token }
    });
    const body = await res.json();
    setFlights(body.data || []);
  };

  useEffect(() => {
    fetchFlights();
  }, []);

  // const handleDelete = async (id) => {
  //   if (!window.confirm('Delete this flight?')) return;
  //   const token = localStorage.getItem('token');
  //   await fetch(`${process.env.REACT_APP_BASE_URL}/api/flights/${id}`, {
  //     method: 'DELETE',
  //     headers: { Authorization: 'Bearer ' + token }
  //   });
  //   fetchFlights();
  // };



// Inside your component or helper function
const handleDelete = async (id) => {
  if (!window.confirm('Delete this flight?')) return;
  const token = localStorage.getItem('token');

  try {
    const res = await fetch(`${process.env.REACT_APP_BASE_URL}/api/flights/${id}`, {
      method: 'DELETE',
      headers: { Authorization: 'Bearer ' + token }
    });

    const body = await res.json();

    if (!res.ok) {
      if (res.status === 400 || res.status === 409) {
        toast.error(body.message || 'Cannot delete flight. It is linked to one or more routes.');
      } else {
        toast.error('Something went wrong. Please try again.');
      }
      return;
    }

    toast.success('Flight deleted successfully');
    fetchFlights();
  } catch (error) {
    toast.error('Server error. Could not delete flight.');
  }
};


  return (
    <>
      <NavBar />

      <div className="container mt-5">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2 className="fw-bold mb-0">All Flights</h2>
          <Link
            to="/flights/new"
            className="btn btn-success btn-lg rounded-pill shadow-lg"
          >
            + Add Flight
          </Link>
        </div>

        <div className="row">
          {flights.length > 0 ? (
            flights.map(f => (
              <div className="col-12 mb-4" key={f.flightId}>
                <div
                  className="card shadow rounded-4 p-3"
                  style={{ cursor: 'pointer' }}
                  onClick={() => setSelectedFlight(f)}
                >
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <h5 className="fw-bold mb-1">{f.flightName} ({f.flightNumber})</h5>
                      <p className="mb-1 text-muted">
                        Owner: {f.owner?.name || `User#${f.owner?.userID}`}
                      </p>
                      <p className="mb-0 text-muted">
                        Seats: {f.totalSeats} • Check-in: {f.checkinKg}kg • Cabin: {f.cabinKg}kg
                      </p>
                    </div>

                    <div className="d-flex gap-2">
                      <Link
                        to={`/flights/${f.flightId}`}
                        onClick={(e) => e.stopPropagation()}
                        className="btn btn-sm btn-outline-primary rounded-circle"
                      >
                        <FaEdit />
                      </Link>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(f.flightId);
                        }}
                        className="btn btn-sm btn-outline-danger rounded-circle"
                      >
                        <FaTrash />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center text-muted">No flights found.</div>
          )}
        </div>
      </div>

      {/* Flight Detail Modal */}
      {selectedFlight && (
        <div className="modal show fade d-block" tabIndex="-1" onClick={() => setSelectedFlight(null)}>
          <div className="modal-dialog modal-dialog-centered" onClick={(e) => e.stopPropagation()}>
            <div className="modal-content rounded-4 shadow-lg">
              <div className="modal-header bg-dark text-white rounded-top-4">
                <h5 className="modal-title">Flight Details</h5>
                <button type="button" className="btn-close btn-close-white" onClick={() => setSelectedFlight(null)}></button>
              </div>
              <div className="modal-body p-4">
                <p><strong>ID:</strong> {selectedFlight.flightId}</p>
                <p><strong>Flight Number:</strong> {selectedFlight.flightNumber}</p>
                <p><strong>Flight Name:</strong> {selectedFlight.flightName}</p>
                <p><strong>Owner:</strong> {selectedFlight.owner?.name || `User#${selectedFlight.owner?.userID}`}</p>
                <p><strong>Total Seats:</strong> {selectedFlight.totalSeats}</p>
                <p><strong>Check-in Baggage:</strong> {selectedFlight.checkinKg} kg</p>
                <p><strong>Cabin Baggage:</strong> {selectedFlight.cabinKg} kg</p>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => setSelectedFlight(null)}>
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
