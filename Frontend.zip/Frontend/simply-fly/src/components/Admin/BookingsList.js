import React, { useState, useEffect } from 'react';
import NavBar from '../NavBar';
import { useParams, useNavigate } from 'react-router-dom';

export default function BookingsList() {
  const [bookings, setBookings] = useState([]);
  const navigate = useNavigate();

  const fetchBookings = async () => {
    const token = localStorage.getItem('token');
    const res = await fetch(`${process.env.REACT_APP_BASE_URL}/api/bookings`, {
      headers: { Authorization: 'Bearer ' + token }
    });
    const body = await res.json();
    setBookings(body.data || []);
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleDelete = async id => {
    if (!window.confirm('Delete this booking?')) return;
    const token = localStorage.getItem('token');
    await fetch(`${process.env.REACT_APP_BASE_URL}/api/bookings/${id}`, {
      method: 'DELETE',
      headers: { Authorization: 'Bearer ' + token }
    });
    fetchBookings();
  };

  return (
    <>
      <NavBar />

      <div className="container mt-5">
        <h2 className="fw-bold mb-4">All Bookings</h2>

       {bookings.length > 0 ? (
  bookings.map(b => (
    <div onClick={() => navigate(`/bookingsAdmin/${b.bookingId}`)} style={{ cursor: 'pointer' }}
      key={b.bookingId}
      className="card shadow-sm rounded-4 mb-3 p-3"
    >
      <div className="d-flex justify-content-between align-items-center mb-2">
        <h6 className="mb-0 fw-bold">Booking #{b.bookingId}</h6>
        <button
          onClick={() => handleDelete(b.bookingId)}
          className="btn btn-danger btn-sm rounded-pill"
        >
          Delete
        </button>
      </div>

      <div className="row g-1 small">
        <div className="col-md-4">
          <div><strong>User:</strong> {b.userEmail || b.userId}</div>
        </div>
        <div className="col-md-4">
          <div><strong>Route:</strong> {`${b.origin} → ${b.destination}`}</div>
        </div>
        <div className="col-md-4">
          <div><strong>Status:</strong> {b.status}</div>
        </div>
        <div className="col-md-4">
          <div><strong>Amount:</strong> ₹{b.totalAmount}</div>
        </div>
        <div className="col-md-4">
          <div><strong>Booked At:</strong> {new Date(b.bookedAt).toLocaleString()}</div>
        </div>
      </div>
    </div>
  ))
) : (
  <div className="text-center py-5 text-muted">
    No bookings found.
  </div>
)}
 
      </div>
    </>
  );
}
