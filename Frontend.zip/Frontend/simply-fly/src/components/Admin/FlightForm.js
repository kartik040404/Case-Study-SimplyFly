import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import NavBar from '../NavBar';
import bgImage from '../assets/images/addFlight.jpg'; 

export default function FlightForm() {
  const { id }     = useParams();
  const isEdit     = Boolean(id);
  const navigate   = useNavigate();

  const [form, setForm] = useState({
    ownerId: '',
    flightNumber: '',
    flightName: '',
    totalSeats: '',
    checkinKg: '',
    cabinKg: '',
    economySeats: '',
    businessSeats: '',
    premiumEconomySeats: '',
    firstClassSeats: ''
  });
  const [owners, setOwners] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    fetch(`${process.env.REACT_APP_BASE_URL}/api/users`, {
      headers: { Authorization: 'Bearer ' + token }
    })
      .then(r => r.json())
      .then(b => setOwners(b.data.filter(u => u.role === 'FLIGHT_OWNER')));

    if (isEdit) {
      fetch(`${process.env.REACT_APP_BASE_URL}/api/flights/${id}`, {
        headers: { Authorization: 'Bearer ' + token }
      })
        .then(r => r.json())
        .then(b => {
          const f = b.data;
          setForm({
            ownerId: f.owner?.userID || '',
            flightNumber: f.flightNumber,
            flightName: f.flightName,
            totalSeats: f.totalSeats,
            checkinKg: f.checkinKg,
            cabinKg: f.cabinKg,
            economySeats: f.economySeats,
            businessSeats: f.businessSeats,
            premiumEconomySeats: f.premiumEconomySeats,
            firstClassSeats: f.firstClassSeats
          });
        });
    }
  }, [id, isEdit]);

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

const handleSubmit = async e => {
  e.preventDefault();

  const totalSeats =
    parseInt(form.economySeats || 0, 10) +
    parseInt(form.businessSeats || 0, 10) +
    parseInt(form.premiumEconomySeats || 0, 10) +
    parseInt(form.firstClassSeats || 0, 10);

  const payload = {
    owner: { userID: parseInt(form.ownerId, 10) },
    flightNumber: form.flightNumber,
    flightName: form.flightName,
    totalSeats,
    checkinKg: parseInt(form.checkinKg, 10),
    cabinKg: parseInt(form.cabinKg, 10),
    economySeats: parseInt(form.economySeats, 10),
    businessSeats: parseInt(form.businessSeats, 10),
    premiumEconomySeats: parseInt(form.premiumEconomySeats, 10),
    firstClassSeats: parseInt(form.firstClassSeats, 10)
  };

  const token = localStorage.getItem('token');
  await fetch(
    isEdit
      ? `${process.env.REACT_APP_BASE_URL}/api/flights/${id}`
      : `${process.env.REACT_APP_BASE_URL}/api/flights`,
    {
      method: isEdit ? 'PUT' : 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + token
      },
      body: JSON.stringify(payload)
    }
  );
  navigate('/flightsAdmin', { replace: true });
};

  return (
    <>
      <NavBar />
      <div className="container-fluid p-0">
        <div className="row g-0">
          <div
            className="col-md-6 d-none d-md-block"
            style={{
              backgroundImage: `url(${bgImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              minHeight: '92vh'
            }}
          />
          <div className="col-md-6 d-flex align-items-center justify-content-center">
            <div className="w-100 px-4 py-5" style={{ maxWidth: '500px' }}>
              <div className="card shadow-lg rounded-4">
                <div className="card-body p-5">
                  <h2 className="mb-4 text-center">
                    {isEdit ? 'Edit Flight' : 'Add Flight'}
                  </h2>
                  <form onSubmit={handleSubmit}>
                    <div className="row g-3">
                      <div className="col-md-6">
                        <div className="form-floating">
                          <select
                            id="ownerId"
                            name="ownerId"
                            className="form-select rounded-pill"
                            value={form.ownerId}
                            onChange={handleChange}
                            required
                          >
                            <option value="">Select Owner</option>
                            {owners.map(o => (
                              <option key={o.userID} value={o.userID}>
                                {o.name}
                              </option>
                            ))}
                          </select>
                          <label htmlFor="ownerId">Owner</label>
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="flightNumber"
                            name="flightNumber"
                            type="text"
                            className="form-control rounded-pill"
                            placeholder="Flight Number"
                            value={form.flightNumber}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="flightNumber">Flight Number</label>
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="flightName"
                            name="flightName"
                            type="text"
                            className="form-control rounded-pill"
                            placeholder="Flight Name"
                            value={form.flightName}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="flightName">Flight Name</label>
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="totalSeats"
                            name="totalSeats"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Total Seats"
                            value={
                              parseInt(form.economySeats || 0) +
    parseInt(form.businessSeats || 0) +
    parseInt(form.premiumEconomySeats || 0) +
    parseInt(form.firstClassSeats || 0)
                            }
                            onChange={handleChange}
                            // required
                            disabled
                          />
                          <label htmlFor="totalSeats">Total Seats</label>
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="checkinKg"
                            name="checkinKg"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Check-in (kg)"
                            value={form.checkinKg}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="checkinKg">Check-in (kg)</label>
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="cabinKg"
                            name="cabinKg"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Cabin (kg)"
                            value={form.cabinKg}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="cabinKg">Cabin (kg)</label>
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="economySeats"
                            name="economySeats"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Economy Seats"
                            value={form.economySeats}
                            onChange={handleChange}
                            disabled={isEdit}
                          />
                          <label htmlFor="economySeats">Economy Seats</label>
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="businessSeats"
                            name="businessSeats"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Business Seats"
                            value={form.businessSeats}
                            onChange={handleChange}
                            disabled={isEdit}
                          />
                          <label htmlFor="businessSeats">Business Seats</label>
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="premiumEconomySeats"
                            name="premiumEconomySeats"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Premium Economy"
                            value={form.premiumEconomySeats}
                            onChange={handleChange}
                            disabled={isEdit}
                          />
                          <label htmlFor="premiumEconomySeats">Premium Economy</label>
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="firstClassSeats"
                            name="firstClassSeats"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="First Class"
                            value={form.firstClassSeats}
                            onChange={handleChange}
                            disabled={isEdit}
                          />
                          <label htmlFor="firstClassSeats">First Class</label>
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="btn btn-primary btn-lg w-100 rounded-pill shadow mt-4"
                    >
                      {isEdit ? 'Update Flight' : 'Create Flight'}
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
