// src/components/UsersList.jsx
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import NavBar from '../NavBar';
import { FaEdit, FaTrash } from 'react-icons/fa';

const UsersList = () => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);

  const fetchUsers = async () => {
    const token = localStorage.getItem('token');
    const res = await fetch(`${process.env.REACT_APP_BASE_URL}/api/users`, {
      headers: { Authorization: 'Bearer ' + token }
    });
    const body = await res.json();
    setUsers(body.data || []);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this user?')) return;
    const token = localStorage.getItem('token');
    await fetch(`${process.env.REACT_APP_BASE_URL}/api/users/${id}`, {
      method: 'DELETE',
      headers: { Authorization: 'Bearer ' + token }
    });
    fetchUsers();
  };

  return (
    <>
      <NavBar />

      <div className="container mt-5">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2 className="fw-bold mb-0">Users</h2>
          <Link to="/users/new" className="btn btn-success btn-lg rounded-pill shadow-lg">
            + Add User
          </Link>
        </div>

<div className="row">
  {users.length > 0 ? (
    users.map((u) => (
      <div className="col-12 mb-4" key={u.userID}>
        <div
          className="card shadow rounded-4 p-3"
          style={{ cursor: 'pointer' }}
          onClick={() => setSelectedUser(u)}
        >
          <div className="d-flex justify-content-between align-items-center">
            <div onClick={(e) => e.stopPropagation()}>
              <h5 className="fw-bold mb-1">{u.name}</h5>
              <p className="mb-1 text-muted">{u.email}</p>
              <span className="badge bg-info text-dark">{u.role}</span>
            </div>

            <div className="d-flex gap-2">
              <Link
                to={`/users/${u.userID}`}
                onClick={(e) => e.stopPropagation()}
                className="btn btn-sm btn-outline-primary rounded-circle"
              >
                <FaEdit />
              </Link>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDelete(u.userID);
                }}
                className="btn btn-sm btn-outline-danger rounded-circle"
              >
                <FaTrash />
              </button>
            </div>
          </div>
        </div>
      </div>
    ))
  ) : (
    <div className="text-center text-muted">No users found.</div>
  )}
</div>

      </div>

      {/* Modal for User Details */}
      {selectedUser && (
        <div className="modal show fade d-block" tabIndex="-1" onClick={() => setSelectedUser(null)}>
          <div className="modal-dialog modal-dialog-centered" onClick={(e) => e.stopPropagation()}>
            <div className="modal-content rounded-4 shadow-lg">
              <div className="modal-header bg-dark text-white rounded-top-4">
                <h5 className="modal-title">User Details</h5>
                <button type="button" className="btn-close btn-close-white" onClick={() => setSelectedUser(null)}></button>
              </div>
              <div className="modal-body p-4">
                <p><strong>ID:</strong> {selectedUser.userID}</p>
                <p><strong>Name:</strong> {selectedUser.name}</p>
                <p><strong>Email:</strong> {selectedUser.email}</p>
                <p><strong>Role:</strong> <span className="badge bg-secondary">{selectedUser.role}</span></p>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => setSelectedUser(null)}>
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default UsersList;
