import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import NavBar from '../NavBar';

const classMeta = {
  ECONOMY:         { label: 'Economy',         bg: 'bg-success bg-opacity-25',    border: 'border-success' },
  BUSINESS:        { label: 'Business',        bg: 'bg-warning bg-opacity-25',    border: 'border-warning' },
  PREMIUM_ECONOMY: { label: 'Premium Economy', bg: 'bg-info bg-opacity-25',       border: 'border-info' },
  FIRST_CLASS:     { label: 'First Class',     bg: 'bg-danger bg-opacity-25',     border: 'border-danger' },
};

export default function BookingDetailsAdmin() {
  const { bookingId } = useParams();
  const [booking, setBooking] = useState(null);
  const [seats, setSeats] = useState([]);
  const [bookedSeatIds, setBookedSeatIds] = useState(new Set());
  const [error, setError] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');

    const fetchBooking = async () => {
      const res = await fetch(`${process.env.REACT_APP_BASE_URL}/api/bookings/${bookingId}`, {
        headers: { Authorization: 'Bearer ' + token }
      });
      if (res.ok) {
        const body = await res.json();
        setBooking(body.data);
        setSeats(body.data.allSeats);
        setBookedSeatIds(new Set(body.data.bookedSeatIds));
      } else {
        setError('Failed to load booking.');
      }
    };

    fetchBooking();
  }, [bookingId]);

  const grouped = seats.length > 0 
    ? seats.reduce((acc, s) => {
        (acc[s.classType] ||= []).push(s);
        return acc;
      }, {})
    : {};

  return (
    <>
      <NavBar />

      <div className="container mt-4">
        <h2 className="mb-3">Booking #{bookingId} Details</h2>

        {error && <div className="alert alert-danger">{error}</div>}

        {booking ? (
          <>
            <div className="card mb-4 p-3">
              <div><strong>User:</strong> {booking.user?.email || booking.user?.userID}</div>
              <div><strong>Route:</strong> {booking.route?.origin} → {booking.route?.destination}</div>
              <div><strong>Status:</strong> {booking.status}</div>
              <div><strong>Total Amount:</strong> ₹{booking.totalAmount}</div>
              <div><strong>Booked At:</strong> {new Date(booking.bookedAt).toLocaleString()}</div>
            </div>

            <div className="d-flex flex-wrap mb-4">
              {Object.entries(classMeta).map(([key, { label, bg, border }]) => (
                <div key={key} className="d-flex align-items-center me-3 mb-2">
                  <div className={`${bg} ${border} rounded me-2`} style={{ width: '20px', height: '20px' }} />
                  <small>{label}</small>
                </div>
              ))}
            </div>

            {Object.keys(grouped).length > 0 ? (
              Object.entries(grouped).map(([cls, list]) => {
                const { label, bg, border } = classMeta[cls] || {};
                return (
                  <div key={cls} className="card mb-3">
                    <div className="card-header">
                      <strong>{label}</strong> — ₹{list[0]?.fare.toFixed(2)} each
                    </div>
                    <div className="card-body">
                      <div className="d-flex flex-wrap">
                        {list.map(s => {
                          const isBooked = bookedSeatIds.has(s.seatId);
                          return (
                            <div
                              key={s.seatId}
                              title={`${label} — ₹${s.fare.toFixed(2)}`}
                              className={`m-1 p-2 border ${border} rounded text-center 
                                    ${isBooked ? `${bg} bg-opacity-100 text-white fw-bold` : `${bg} bg-opacity-25`}
`}
                              style={{ width: '60px' }}
                            >
                              {s.seatNumber}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div>No seats data available.</div>
            )}
          </>
        ) : (
          !error && <div>Loading...</div>
        )}
      </div>
    </>
  );
}
