import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import bgImage from '../assets/images/addRouteFlightOwner.jpg';
import NavBar from '../NavBar';

export default function RouteForm() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const [flights, setFlights] = useState([]);
  const [loadedRoute, setLoadedRoute] = useState(null);
  const [form, setForm] = useState({
    flightId: '',
    origin: '',
    destination: '',
    departureTs: '',
    arrivalTs: '',
    economyFare: '',
    businessFare: '',
    premiumEconomyFare: '',
    firstClassFare: ''
  });
  const [error, setError] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');

    // load flights
    fetch(`${process.env.REACT_APP_BASE_URL}/api/flights`, {
      headers: { Authorization: 'Bearer ' + token }
    })
      .then(r => r.json())
      .then(b =>
        // setFlights(b.data.filter(f => f.owner?.userID === user.userID))
        setFlights(b.data)
      )
      .catch(() => setError('Failed to load flights'));

    // if editing, load route
    if (isEdit) {
      fetch(`${process.env.REACT_APP_BASE_URL}/api/routes/${id}`, {
        headers: { Authorization: 'Bearer ' + token }
      })
        .then(r => r.json())
        .then(b => setLoadedRoute(b.data))
        .catch(() => setError('Failed to load route'));
    }
  }, [id, user.userID]);

  // wait for both route & flights then fill form
  useEffect(() => {
    if (loadedRoute && flights.length > 0) {
      const matchedFlight = flights.find(f =>
        f.flightNumber === loadedRoute.flightNumber &&
        f.flightName === loadedRoute.flightName
      );
      const flightId = matchedFlight ? matchedFlight.flightId : '';

      setForm({
        flightId,
        origin: loadedRoute.origin,
        destination: loadedRoute.destination,
        departureTs: loadedRoute.departureTs.slice(0,16),
        arrivalTs: loadedRoute.arrivalTs.slice(0,16),
        economyFare: loadedRoute.economyFare,
        businessFare: loadedRoute.businessFare,
        premiumEconomyFare: loadedRoute.premiumEconomyFare,
        firstClassFare: loadedRoute.firstClassFare
      });
    }
  }, [loadedRoute, flights]);

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    const token = localStorage.getItem('token');
    const payload = {
      flight: { flightId: parseInt(form.flightId, 10) },
      origin: form.origin,
      destination: form.destination,
      departureTs: form.departureTs,
      arrivalTs: form.arrivalTs,
      economyFare: parseFloat(form.economyFare),
      businessFare: parseFloat(form.businessFare),
      premiumEconomyFare: parseFloat(form.premiumEconomyFare),
      firstClassFare: parseFloat(form.firstClassFare)
    };
    const url = isEdit
      ? `${process.env.REACT_APP_BASE_URL}/api/routes/${id}`
      : `${process.env.REACT_APP_BASE_URL}/api/routes`;
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + token
        },
        body: JSON.stringify(payload)
      });
      const body = await res.json();
      if (res.ok && body.success) {
        navigate('/routesAdmin', { replace: true });
      } else {
        setError(body.message || 'Failed to save route');
      }
    } catch {
      setError('Server error, please try again');
    }
  };

  return (
    <>
      <NavBar/>

      <div className="container-fluid p-0">
        <div className="row g-0">
          <div
            className="col-md-6 d-none d-md-block"
            style={{
              backgroundImage: `url(${bgImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              minHeight: '92vh'
            }}
          />

          <div className="col-md-6 d-flex align-items-center justify-content-center">
            <div className="w-100 px-4 py-5" style={{ maxWidth: '500px' }}>
              <div className="card shadow-lg rounded-4 overflow-hidden">
                <div className="card-body p-5">
                  <h2 className="mb-4 text-center">
                    {isEdit ? 'Edit Route' : 'Add New Route'}
                  </h2>

                  {error && <div className="alert alert-danger">{error}</div>}

                  <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                      <div className="form-floating">
                        <select
                          id="flightId"
                          name="flightId"
                          className="form-select rounded-pill"
                          value={form.flightId}
                          onChange={handleChange}
                          required
                        >
                          <option value="">Select Flight</option>
                          {flights.map(f => (
                            <option key={f.flightId} value={f.flightId}>
                              {f.flightNumber} – {f.flightName}
                            </option>
                          ))}
                        </select>
                        <label htmlFor="flightId">Flight</label>
                      </div>
                    </div>

                    <div className="row g-3">
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="origin"
                            name="origin"
                            type="text"
                            className="form-control rounded-pill"
                            placeholder="Origin"
                            value={form.origin}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="origin">Origin</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="destination"
                            name="destination"
                            type="text"
                            className="form-control rounded-pill"
                            placeholder="Destination"
                            value={form.destination}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="destination">Destination</label>
                        </div>
                      </div>
                    </div>

                    <div className="row g-3 mt-3">
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="departureTs"
                            name="departureTs"
                            type="datetime-local"
                            className="form-control rounded-pill"
                            placeholder="Departure Time"
                            value={form.departureTs}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="departureTs">Departure Time</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="arrivalTs"
                            name="arrivalTs"
                            type="datetime-local"
                            className="form-control rounded-pill"
                            placeholder="Arrival Time"
                            value={form.arrivalTs}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="arrivalTs">Arrival Time</label>
                        </div>
                      </div>
                    </div>

                    <div className="row g-3 mt-3">
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="economyFare"
                            name="economyFare"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Economy Fare"
                            value={form.economyFare}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="economyFare">Economy Fare</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="businessFare"
                            name="businessFare"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Business Fare"
                            value={form.businessFare}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="businessFare">Business Fare</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="premiumEconomyFare"
                            name="premiumEconomyFare"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="Premium Economy Fare"
                            value={form.premiumEconomyFare}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="premiumEconomyFare">Premium Economy Fare</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-floating">
                          <input
                            id="firstClassFare"
                            name="firstClassFare"
                            type="number"
                            className="form-control rounded-pill"
                            placeholder="First Class Fare"
                            value={form.firstClassFare}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="firstClassFare">First Class Fare</label>
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="btn btn-primary btn-lg w-100 rounded-pill shadow mt-4"
                    >
                      {isEdit ? 'Update Route' : 'Create Route'}
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
