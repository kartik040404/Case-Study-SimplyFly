// src/components/AdminDashboard.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import NavBar from '../NavBar';
import bgImage from '../assets/images/adminDashboard1.jpg';

export default function AdminDashboard() {
  return (
    <div
      className="position-relative"
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        minHeight: '100vh'
      }}
    >
      <div
        className="position-absolute top-0 start-0 w-100 h-100"
        // style={{ backgroundColor: 'rgba(0, 0, 0, 0.6)' }}
      />

      <div className="position-relative">
        <NavBar />

        <div className="container text-center text-white py-5">
          <h1 className="display-4 fw-bold">Welcome Back, Admin!</h1>
          <p className="lead mb-4">
            Use the navigation above to manage users, flights, and bookings.
          </p>
          {/* <Link to="/profileAdmin" className="btn btn-light btn-lg rounded-pill">
            View Profile
          </Link> */}
        </div>
      </div>
    </div>
  );
}
