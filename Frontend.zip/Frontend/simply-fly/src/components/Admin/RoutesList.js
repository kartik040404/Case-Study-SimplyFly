import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import NavBar from '../NavBar';

const RoutesList = () => {
  const [routes, setRoutes] = useState([]);
  const [error, setError] = useState('');
  const [selectedRoute, setSelectedRoute] = useState(null);
  const navigate = useNavigate();

  const fetchRoutes = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${process.env.REACT_APP_BASE_URL}/api/routes`, {
        headers: { 'Authorization': 'Bearer ' + token }
      });
      const body = await res.json();
      setRoutes(body.data);
    } catch {
      setError('Failed to load routes.');
    }
  };

  useEffect(() => { fetchRoutes(); }, []);

  const handleDelete = async id => {
    if (!window.confirm('Delete this route?')) return;
    try {
      const token = localStorage.getItem('token');
      await fetch(`${process.env.REACT_APP_BASE_URL}/api/routes/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': 'Bearer ' + token }
      });
      setRoutes(prev => prev.filter(r => r.routeId !== id));
    } catch {
      setError('Failed to delete route.');
    }
  };

  return (
    <>
      <NavBar />

      <div className="container mt-5">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h2 className="fw-bold mb-0">All Routes</h2>
          <Link
            to="/routes/new"
            style={{
              padding: '10px 20px',
              background: 'green',
              color: 'white',
              borderRadius: '20px',
              textDecoration: 'none'
            }}
          >
            + Add Route
          </Link>
        </div>

        {error && <div style={{ color: 'red', marginBottom: '15px' }}>{error}</div>}

        {routes.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            {routes.map(r => (
              <div
                key={r.routeId}
                onClick={() => setSelectedRoute(r)}
                style={{
                  border: '1px solid #ddd',
                  borderRadius: '10px',
                  padding: '15px',
                  width: '100%',
                  boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer'
                }}
              >
                <div>
                  <h4 style={{ margin: '0 0 5px' }}>
                    {r.flight?.flightNumber}: {r.origin} → {r.destination}
                  </h4>
                  <p style={{ margin: 0 }}>
                    Dep: {new Date(r.departureTs).toLocaleString()} | Arr: {new Date(r.arrivalTs).toLocaleString()}
                  </p>
                </div>
                <div>
                  <span
                    onClick={e => { e.stopPropagation(); navigate(`/routes/${r.routeId}`); }}
                    style={{ marginRight: '15px', fontSize: '18px', cursor: 'pointer' }}
                  >
                    ✏️
                  </span>
                  <span
                    onClick={e => { e.stopPropagation(); handleDelete(r.routeId); }}
                    style={{ fontSize: '18px', cursor: 'pointer' }}
                  >
                    🗑️
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ textAlign: 'center', color: '#777' }}>No routes found.</p>
        )}
      </div>

      {/* Details Modal */}
      {selectedRoute && (
  <div style={{
    position: 'fixed',
    top: 0, left: 0,
    width: '100%', height: '100%',
    background: 'rgba(0, 0, 0, 0.5)',
    backdropFilter: 'blur(4px)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000
  }}>
    <div style={{
      background: '#fff',
      borderRadius: '20px',
      padding: '30px',
      width: '100%',
      maxWidth: '520px',
      boxShadow: '0 8px 20px rgba(0,0,0,0.25)',
      fontFamily: 'Segoe UI, sans-serif'
    }}>
      <h3 style={{ marginBottom: '20px', color: '#333', fontWeight: '600' }}>Route Details</h3>

      <div style={{ lineHeight: '1.7', color: '#444', fontSize: '15px' }}>
        <p><strong>ID:</strong> {selectedRoute.routeId}</p>
        <p><strong>Flight:</strong> {selectedRoute.flight?.flightNumber} - {selectedRoute.flight?.flightName}</p>
        <p><strong>Origin:</strong> {selectedRoute.origin}</p>
        <p><strong>Destination:</strong> {selectedRoute.destination}</p>
        <p><strong>Departure:</strong> {new Date(selectedRoute.departureTs).toLocaleString()}</p>
        <p><strong>Arrival:</strong> {new Date(selectedRoute.arrivalTs).toLocaleString()}</p>
        <p><strong>Economy Fare:</strong> ₹{selectedRoute.economyFare}</p>
        <p><strong>Business Fare:</strong> ₹{selectedRoute.businessFare}</p>
        <p><strong>Premium Economy Fare:</strong> ₹{selectedRoute.premiumEconomyFare}</p>
        <p><strong>First Class Fare:</strong> ₹{selectedRoute.firstClassFare}</p>
      </div>

      <div className="d-flex justify-content-end gap-2 mt-4">
        <button
          onClick={() => setSelectedRoute(null)}
          className="btn btn-outline-secondary rounded-pill shadow-sm"
        >
          Close
        </button>
        <button
          onClick={() => {
            navigate(`/routes/${selectedRoute.routeId}`);
            setSelectedRoute(null);
          }}
          className="btn btn-primary rounded-pill shadow-sm"
        >
          Edit
        </button>
        <button
          onClick={() => {
            handleDelete(selectedRoute.routeId);
            setSelectedRoute(null);
          }}
          className="btn btn-danger rounded-pill shadow-sm"
        >
          Delete
        </button>
      </div>
    </div>
  </div>
)}

    </>
  );
};

export default RoutesList;
