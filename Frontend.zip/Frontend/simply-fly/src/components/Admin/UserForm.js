// src/components/UserForm.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import NavBar from '../NavBar';
import bgImage from '../assets/images/addUser.jpg'; // put your chosen image here

export default function UserForm() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    gender: '',
    contactNumber: '',
    address: '',
    role: ''
  });

  useEffect(() => {
    if (isEdit) {
      const token = localStorage.getItem('token');
      fetch(`${process.env.REACT_APP_BASE_URL}/api/users/${id}`, {
        headers: { Authorization: 'Bearer ' + token }
      })
        .then(r => r.json())
        .then(b => {
          const { password, ...rest } = b.data;
          setForm({ ...rest, password: '' });
        });
    }
  }, [id, isEdit]);

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const token = localStorage.getItem('token');

    if (isEdit) {
      await fetch(`${process.env.REACT_APP_BASE_URL}/api/users/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + token
        },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          gender: form.gender,
          contactNumber: form.contactNumber,
          address: form.address,
          role: form.role
        })
      });
    } else {
      await fetch(`${process.env.REACT_APP_BASE_URL}/api/users`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + token
        },
        body: JSON.stringify(form)
      });
    }

    navigate('/users', { replace: true });
  };

  return (
    <>
      <NavBar />
      <div className="container-fluid">
        <div className="row g-0">
          {/* Left image panel */}
          <div
            className="col-md-6 d-none d-md-block"
            style={{
              backgroundImage: `url(${bgImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              minHeight: '92vh'
            }}
          />

          {/* Right form panel */}
          <div className="col-md-6 d-flex align-items-center">
            <div className="w-100 px-4 py-5">
              <div className="card shadow-lg rounded-4">
                <div className="card-body p-5">
                  <h2 className="mb-4 text-center">
                    {isEdit ? 'Edit User' : 'Add User'}
                  </h2>
                  <form onSubmit={handleSubmit}>
                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <div className="form-floating">
                          <input
                            id="name"
                            name="name"
                            type="text"
                            className="form-control rounded-pill"
                            placeholder="Name"
                            value={form.name}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="name">Name</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-3">
                        <div className="form-floating">
                          <input
                            id="email"
                            name="email"
                            type="email"
                            className="form-control rounded-pill"
                            placeholder="Email"
                            value={form.email}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="email">Email</label>
                        </div>
                      </div>
                    </div>

                    {!isEdit && (
                      <div className="mb-3">
                        <div className="form-floating">
                          <input
                            id="password"
                            name="password"
                            type="password"
                            className="form-control rounded-pill"
                            placeholder="Password"
                            value={form.password}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="password">Password</label>
                        </div>
                      </div>
                    )}

                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <div className="form-floating">
                          <select
                            id="gender"
                            name="gender"
                            className="form-select rounded-pill"
                            value={form.gender}
                            onChange={handleChange}
                            required
                          >
                            <option value="">Select Gender</option>
                            <option>Male</option>
                            <option>Female</option>
                            <option>Other</option>
                          </select>
                          <label htmlFor="gender">Gender</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-3">
                        <div className="form-floating">
                          <input
                            id="contactNumber"
                            name="contactNumber"
                            type="text"
                            className="form-control rounded-pill"
                            placeholder="Contact Number"
                            value={form.contactNumber}
                            onChange={handleChange}
                            required
                          />
                          <label htmlFor="contactNumber">Contact Number</label>
                        </div>
                      </div>
                    </div>

                    <div className="mb-3">
                      <div className="form-floating">
                        <input
                          id="address"
                          name="address"
                          type="text"
                          className="form-control rounded-pill"
                          placeholder="Address"
                          value={form.address}
                          onChange={handleChange}
                          required
                        />
                        <label htmlFor="address">Address</label>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="form-floating">
                        <select
                          id="role"
                          name="role"
                          className="form-select rounded-pill"
                          value={form.role}
                          onChange={handleChange}
                          required
                        >
                          <option value="">Select Role</option>
                          <option value="PASSENGER">Passenger</option>
                          <option value="FLIGHT_OWNER">Flight Owner</option>
                          <option value="ADMIN">Admin</option>
                        </select>
                        <label htmlFor="role">Role</label>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="btn btn-primary btn-lg w-100 rounded-pill shadow"
                    >
                      {isEdit ? 'Update User' : 'Create User'}
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
