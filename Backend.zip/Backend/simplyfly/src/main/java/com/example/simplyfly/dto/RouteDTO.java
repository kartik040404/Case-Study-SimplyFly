package com.example.simplyfly.dto;

import java.time.LocalDateTime;

public class RouteDTO {
    public int     routeId;
    public String  origin, destination;
    public LocalDateTime departureTs, arrivalTs;
    public String  flightNumber, flightName;
    public double  economyFare, businessFare, premiumEconomyFare, firstClassFare;
	
    public RouteDTO() {
		super();
	}
	public RouteDTO(int routeId, String origin, String destination, LocalDateTime departureTs, LocalDateTime arrivalTs,
			String flightNumber, String flightName, double economyFare, double businessFare, double premiumEconomyFare,
			double firstClassFare) {
		super();
		this.routeId = routeId;
		this.origin = origin;
		this.destination = destination;
		this.departureTs = departureTs;
		this.arrivalTs = arrivalTs;
		this.flightNumber = flightNumber;
		this.flightName = flightName;
		this.economyFare = economyFare;
		this.businessFare = businessFare;
		this.premiumEconomyFare = premiumEconomyFare;
		this.firstClassFare = firstClassFare;
	}
	public int getRouteId() {
		return routeId;
	}
	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public LocalDateTime getDepartureTs() {
		return departureTs;
	}
	public void setDepartureTs(LocalDateTime departureTs) {
		this.departureTs = departureTs;
	}
	public LocalDateTime getArrivalTs() {
		return arrivalTs;
	}
	public void setArrivalTs(LocalDateTime arrivalTs) {
		this.arrivalTs = arrivalTs;
	}
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public double getEconomyFare() {
		return economyFare;
	}
	public void setEconomyFare(double economyFare) {
		this.economyFare = economyFare;
	}
	public double getBusinessFare() {
		return businessFare;
	}
	public void setBusinessFare(double businessFare) {
		this.businessFare = businessFare;
	}
	public double getPremiumEconomyFare() {
		return premiumEconomyFare;
	}
	public void setPremiumEconomyFare(double premiumEconomyFare) {
		this.premiumEconomyFare = premiumEconomyFare;
	}
	public double getFirstClassFare() {
		return firstClassFare;
	}
	public void setFirstClassFare(double firstClassFare) {
		this.firstClassFare = firstClassFare;
	}
    
}
