package com.example.simplyfly.service;

import com.example.simplyfly.entity.BookingHistory;
import com.example.simplyfly.repository.BookingHistoryRepo;
import com.example.simplyfly.repository.BookingRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class BookingHistoryService {

    @Autowired
    private BookingHistoryRepo bookingHistoryRepo;

    @Autowired
    private BookingRepo bookingRepo;

    public ResponseEntity<Map<String,Object>> getBookingHistory(int bookingId) {
        Map<String,Object> body = new HashMap<>();

        // Check booking exists
        if (!bookingRepo.existsById(bookingId)) {
            body.put("success", false);
            body.put("message", "Booking not found with id " + bookingId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }

        // Filter history records for this booking
        List<BookingHistory> history = bookingHistoryRepo.findAll().stream()
            .filter(h -> h.getBooking() != null 
                      && h.getBooking().getBookingId() == bookingId)
            .collect(Collectors.toList());

        body.put("success", true);
        body.put("data", history);
        return ResponseEntity.ok(body);
    }
}
