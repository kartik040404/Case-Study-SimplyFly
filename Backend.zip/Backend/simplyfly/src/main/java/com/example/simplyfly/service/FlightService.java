package com.example.simplyfly.service;

import com.example.simplyfly.entity.Flight;
import com.example.simplyfly.entity.Seat;
import com.example.simplyfly.enums.SeatClass;
import com.example.simplyfly.enums.SeatStatus;
import com.example.simplyfly.repository.FlightRepo;
import com.example.simplyfly.repository.SeatRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class FlightService {

    @Autowired
    private FlightRepo flightRepo;
    
    @Autowired
    private SeatRepo seatRepo;

    public ResponseEntity<Map<String,Object>> getAllFlights() {
        List<Flight> flights = flightRepo.findAll();
        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", flights);
        return ResponseEntity.ok(body);
    }

    public ResponseEntity<Map<String,Object>> getFlightById(int flightId) {
        Flight flight = flightRepo.findById(flightId)
                .orElseThrow(() -> new RuntimeException("Flight not found with id " + flightId));
        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", flight);
        return ResponseEntity.ok(body);
    }

    public ResponseEntity<Map<String,Object>> createFlight(Flight flight) {
        Flight saved = flightRepo.save(flight);
        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("message", "Flight created successfully");
        body.put("data", saved);
        return ResponseEntity.ok(body);
    }
//    public ResponseEntity<Map<String,Object>> createFlight(Flight flight) {
//        // 1) save the flight
//        Flight saved = flightRepo.save(flight);
//
//        // 2) generate seats
//        int total = saved.getTotalSeats();
//        // strip spaces/punctuation from name for prefix
//        String prefix = saved.getFlightName().replaceAll("\\W+","");
//
//        List<Seat> seats = new ArrayList<>(total);
//        for (int i = 1; i <= total; i++) {
//            Seat s = new Seat();
//            // associate to route if your model requires a route—
//            // otherwise just prefix off the flight name:
//            s.setSeatNumber(prefix + i);
//            s.setClassType(SeatClass.ECONOMY);
//            s.setStatus(SeatStatus.AVAILABLE);
//            seats.add(s);
//        }
//        // 3) save them all
//        seatRepo.saveAll(seats);
//
//        // 4) build response
//        Map<String,Object> body = new HashMap<>();
//        body.put("success", true);
//        body.put("message", "Flight created successfully");
//        body.put("data", saved);
//        return ResponseEntity.ok(body);
//    }

    public ResponseEntity<Map<String,Object>> updateFlight(int flightId, Flight details) {
        Flight flight = flightRepo.findById(flightId)
                .orElseThrow(() -> new RuntimeException("Flight not found with id " + flightId));

        flight.setOwner(details.getOwner());
        flight.setFlightNumber(details.getFlightNumber());
        flight.setFlightName(details.getFlightName());
        flight.setTotalSeats(details.getTotalSeats());
        flight.setCheckinKg(details.getCheckinKg());
        flight.setCabinKg(details.getCabinKg());

        Flight updated = flightRepo.save(flight);

        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("message", "Flight updated successfully");
        body.put("data", updated);
        return ResponseEntity.ok(body);
    }

    public ResponseEntity<Map<String,Object>> deleteFlight(int flightId) {
        Flight flight = flightRepo.findById(flightId)
                .orElseThrow(() -> new RuntimeException("Flight not found with id " + flightId));
        flightRepo.delete(flight);

        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("message", "Flight deleted successfully");
        return ResponseEntity.ok(body);
    }
}
