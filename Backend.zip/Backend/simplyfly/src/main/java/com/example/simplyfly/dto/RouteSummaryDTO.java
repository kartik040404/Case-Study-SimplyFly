package com.example.simplyfly.dto;

import java.time.LocalDateTime;

public class RouteSummaryDTO {
    private Integer routeId;
    private String origin;
    private String destination;
    private LocalDateTime departureTs;
    private LocalDateTime arrivalTs;
    private String flightNumber;
    private String flightName;
//    private double fare;    // economyFare, or whichever class you want to show

    public RouteSummaryDTO(
        Integer routeId,
        String origin,
        String destination,
        LocalDateTime departureTs,
        LocalDateTime arrivalTs,
        String flightNumber,
        String flightName
//        double fare
    ) {
        this.routeId      = routeId;
        this.origin       = origin;
        this.destination  = destination;
        this.departureTs  = departureTs;
        this.arrivalTs    = arrivalTs;
        this.flightNumber = flightNumber;
        this.flightName   = flightName;
//        this.fare         = fare;
    }

    // … getters (no setters needed if immutable) …

    public Integer getRouteId() { return routeId; }
    public String getOrigin() { return origin; }
    public String getDestination() { return destination; }
    public LocalDateTime getDepartureTs() { return departureTs; }
    public LocalDateTime getArrivalTs()   { return arrivalTs;   }
    public String getFlightNumber() { return flightNumber; }
    public String getFlightName()   { return flightName;   }
//    public double getFare()         { return fare;         }
}
