package com.example.simplyfly.controller;

import com.example.simplyfly.dto.LoginRequest;
import com.example.simplyfly.entity.User;
import com.example.simplyfly.enums.Role;
import com.example.simplyfly.security.JWTCheck;
import com.example.simplyfly.service.AuthService;

import jakarta.servlet.http.HttpSession;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

	@Autowired
	private AuthService authService;

	@Autowired
	private JWTCheck jwtCheck;
	
	@PostMapping("/login")
	public ResponseEntity<Map<String,Object>>login(@RequestBody LoginRequest req){
		return authService.loginAPI(req);
	}
	
	@PostMapping("/register")
	public ResponseEntity<Map<String,Object>>register(@RequestBody User user){
		return authService.registerAPI(user);
	}
}