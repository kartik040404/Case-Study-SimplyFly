package com.example.simplyfly.enums;

public enum HistoryAction   { BOOKED, CANCELLED }

