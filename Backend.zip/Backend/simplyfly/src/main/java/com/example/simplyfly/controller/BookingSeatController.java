package com.example.simplyfly.controller;

 
import com.example.simplyfly.entity.BookingSeat;
import com.example.simplyfly.service.BookingSeatService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
public class BookingSeatController {

    @Autowired
    private BookingSeatService bookingSeatService;

    @PostMapping("/{bookingId}/seats")
    public ResponseEntity<Map<String,Object>> addSeatToBooking(
            @PathVariable int bookingId,
            @RequestBody BookingSeat bookingSeat) {
        return bookingSeatService.addSeatToBooking(bookingId, bookingSeat);
    }

    @DeleteMapping("/{bookingId}/seats/{seatId}")
    public ResponseEntity<Map<String,Object>> removeSeatFromBooking(
            @PathVariable int bookingId,
            @PathVariable int seatId) {
        return bookingSeatService.removeSeatFromBooking(bookingId, seatId);
    }
}
