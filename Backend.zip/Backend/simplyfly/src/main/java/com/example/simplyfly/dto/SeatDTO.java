// src/main/java/com/example/simplyfly/dto/SeatDTO.java
package com.example.simplyfly.dto;

import com.example.simplyfly.enums.SeatClass;

public class SeatDTO {
    private Integer   seatId;
    private String    seatNumber;
    private SeatClass classType;
    private double    fare;

    public SeatDTO(Integer seatId, String seatNumber, SeatClass classType, double fare) {
        this.seatId     = seatId;
        this.seatNumber = seatNumber;
        this.classType  = classType;
        this.fare       = fare;
    }

    public Integer   getSeatId()     { return seatId; }
    public String    getSeatNumber() { return seatNumber; }
    public SeatClass getClassType()  { return classType; }
    public double    getFare()       { return fare; }
}
