package com.example.simplyfly.controller;

import com.example.simplyfly.entity.Route;
import com.example.simplyfly.service.RouteService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/routes")
public class RouteController {

    @Autowired
    private RouteService routeService;

    @GetMapping
    public ResponseEntity<Map<String,Object>> getAllRoutes() {
        return routeService.getAllRoutes();
    }

    @GetMapping("/{routeId}")
    public ResponseEntity<Map<String,Object>> getRouteById(@PathVariable int routeId) {
        return routeService.getRouteById(routeId);
    }

    @PostMapping
    public ResponseEntity<Map<String,Object>> createRoute(@RequestBody Route route) {
        return routeService.createRoute(route);
    }

    @PutMapping("/{routeId}")
    public ResponseEntity<Map<String,Object>> updateRoute(
            @PathVariable int routeId,
            @RequestBody Route routeDetails) {
        return routeService.updateRoute(routeId, routeDetails);
    }

    @DeleteMapping("/{routeId}")
    public ResponseEntity<Map<String,Object>> deleteRoute(@PathVariable int routeId) {
        return routeService.deleteRoute(routeId);
    }

    @GetMapping("/search")
    public ResponseEntity<Map<String,Object>> searchRoutes(
            @RequestParam String origin,
            @RequestParam String destination,
            @RequestParam String date) {
        return routeService.searchRoutes(origin, destination, date);
    }
}
