package com.example.simplyfly.enums;

public enum BookingStatus   { BOOKED, CANCELLED }

