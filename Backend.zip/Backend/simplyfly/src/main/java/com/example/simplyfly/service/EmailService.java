package com.example.simplyfly.service;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;

//import javax.mail.internet.MimeMessage;

import com.example.simplyfly.entity.Booking;
import com.example.simplyfly.entity.User;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import jakarta.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import org.springframework.stereotype.Service;

@Service
public class EmailService {

  @Autowired
  private JavaMailSender mailSender;

//  @Autowired
//  private BookingService bookingService;

  public void sendTicketEmail(Booking booking) throws Exception {
//    Booking booking = bookingService.findById(bookingId);
    User user = booking.getUser();  
    Integer bookingId=booking.getBookingId();
 
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    BitMatrix matrix = new QRCodeWriter()
        .encode(bookingId.toString(), BarcodeFormat.QR_CODE, 200, 200);
    MatrixToImageWriter.writeToStream(matrix, "PNG", baos);
    ByteArrayResource qrImage = new ByteArrayResource(baos.toByteArray());

    MimeMessage msg = mailSender.createMimeMessage();
    MimeMessageHelper helper = new MimeMessageHelper(msg, true, "UTF-8");
//    System.out.println(user.getEmail()+"============================");
    helper.setTo(user.getEmail());
    helper.setSubject("Your SimplyFly Ticket — Booking #" + bookingId);

    String html = """
      <p>Hi %s,</p>
      <p>Thank you for booking with SimplyFly!<br>
      Your booking ID is <strong>%d</strong>.</p>
      <p>Please save this QR code as your boarding pass:</p>
      <img src='cid:qrImage' alt='QR code' />
      <p>Safe travels!</p>
      """.formatted(user.getName(), bookingId);

    helper.setText(html, true);
    helper.addInline("qrImage", qrImage, "image/png");

    mailSender.send(msg);
  }
  
  public void sendCancellationEmail(Booking booking) throws Exception {
//	    Booking booking = bookingService.findById(bookingId);
	    User user = booking.getUser();
	    Integer bookingId=booking.getBookingId();
	    MimeMessage msg = mailSender.createMimeMessage();
	    MimeMessageHelper helper = new MimeMessageHelper(msg, true, "UTF-8");

	    helper.setTo(user.getEmail());
	    helper.setSubject("Booking Cancelled — Refund Initiated: #" + bookingId);

	    String html = """
	      <p>Hi %s,</p>
	      <p>Your booking with ID <strong>%d</strong> has been <span style="color:red;"><strong>cancelled</strong></span>.</p>
	      <p>The refund process has been initiated. You should receive the refunded amount within 5–7 business days.</p>
	      <p>If you didn’t request this cancellation, please contact our support team immediately.</p>
	      <p>Thanks for choosing SimplyFly!</p>
	      """.formatted(user.getName(), bookingId);

	    helper.setText(html, true);
	    mailSender.send(msg);
	}


}
