package com.example.simplyfly.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.simplyfly.entity.Seat;

public interface SeatRepo  extends JpaRepository<Seat,Integer>{
	List<Seat> findByRoute_RouteId(int routeId);
	void deleteAllByRouteRouteId(int routeId);

}
