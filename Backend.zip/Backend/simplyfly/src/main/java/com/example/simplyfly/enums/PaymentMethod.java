package com.example.simplyfly.enums;

public enum PaymentMethod   { UPI, CARD, NETBANKING }

