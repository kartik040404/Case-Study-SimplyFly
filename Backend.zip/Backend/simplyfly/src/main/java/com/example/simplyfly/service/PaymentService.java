package com.example.simplyfly.service;

import com.example.simplyfly.entity.Booking;
import com.example.simplyfly.entity.Payment;
import com.example.simplyfly.repository.BookingRepo;
import com.example.simplyfly.repository.PaymentRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepo paymentRepo;

    @Autowired
    private BookingRepo bookingRepo;
    
    @Autowired
    private EmailService emailService;


    public ResponseEntity<Map<String,Object>> addPaymentToBooking(int bookingId, Payment details) {
        Map<String,Object> body = new HashMap<>();

        Optional<Booking> bookingOpt = bookingRepo.findById(bookingId);
        if (bookingOpt.isEmpty()) {
            body.put("success", false);
            body.put("message", "Booking not found with id " + bookingId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }

        Payment p = new Payment();
        p.setPaymentId(details.getPaymentId());
        p.setBooking(bookingOpt.get());
        p.setPaymentMethod(details.getPaymentMethod());
        p.setPaymentStatus(details.getPaymentStatus());
        p.setAmountPaid(details.getAmountPaid());
        p.setPaymentDate(details.getPaymentDate());

        Payment saved = paymentRepo.save(p);
        body.put("success", true);
        body.put("message", "Payment recorded successfully");
        
        try {
            emailService.sendTicketEmail(bookingOpt.get());
          } catch (Exception e) {
            e.printStackTrace();
          }
        return ResponseEntity.ok(body);
    }

    public ResponseEntity<Map<String,Object>> getPaymentById(int id) {
        Optional<Payment> opt = paymentRepo.findById(id);
        Map<String,Object> body = new HashMap<>();
        if (opt.isPresent()) {
            body.put("success", true);
            body.put("data", opt.get());
            return ResponseEntity.ok(body);
        } else {
            body.put("success", false);
            body.put("message", "Payment not found with id " + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
    }

    public ResponseEntity<Map<String,Object>> getPaymentsForBooking(int bookingId) {
        Map<String,Object> body = new HashMap<>();

        Optional<Booking> bookingOpt = bookingRepo.findById(bookingId);
        if (bookingOpt.isEmpty()) {
            body.put("success", false);
            body.put("message", "Booking not found with id " + bookingId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }

        List<Payment> payments = paymentRepo.findAll().stream()
            .filter(p -> p.getBooking() != null
                      && p.getBooking().getBookingId() == bookingId)
            .collect(Collectors.toList());

        body.put("success", true);
        body.put("data", payments);
        return ResponseEntity.ok(body);
    }
}
