package com.example.simplyfly.service;

import com.example.simplyfly.entity.User;
import com.example.simplyfly.enums.Role;
import com.example.simplyfly.repository.UserRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;

    public ResponseEntity<Map<String,Object>> getAllUsers() {
        List<User> users = userRepo.findAll();
        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", users);
        return ResponseEntity.ok(body);
    }

    public ResponseEntity<Map<String,Object>> getUserById(int id) {
        Optional<User> user = userRepo.findById(id);
        Map<String,Object> body = new HashMap<>();
        if(user.isPresent()) {        	
        body.put("success", true);
        body.put("data", user.get());
        return ResponseEntity.ok(body);
        }
        body.put("success", false);
        body.put("message", "User not found");
        return new ResponseEntity<Map<String,Object>>(body,HttpStatus.NOT_FOUND);
    }

    
    public ResponseEntity<Map<String,Object>> createUser(User user){
    	Map<String,Object> body = new HashMap<>();
    	 if (userRepo.existsByEmail(user.getEmail())) {
    		 	body.put("success", false);
	        	body.put("message", "User already exists");
	            return new ResponseEntity<>(body,HttpStatus.BAD_REQUEST);
	        }
	        user.setCreatedAt(LocalDateTime.now());
	        userRepo.save(user);
        	 body.put("success", true);
        	 body.put("message", "Register Successfully");
        	 body.put("data", user);
            return new ResponseEntity<>(body,HttpStatus.OK);
    }
    
    public ResponseEntity<Map<String,Object>> updateUser(int id, User details) {
        Optional<User> user = userRepo.findById(id);
        Map<String,Object> body = new HashMap<>();
        if(user.isPresent()) {
        	details.setUserID(id);
        	User updated = userRepo.save(details);
        	body.put("success", true);
        	body.put("message", "User updated successfully");
        	body.put("data", updated);        	
        }
        else {
        body.put("success", false);
    	body.put("message", "User not found");
        }
        return ResponseEntity.ok(body);
    }

    public ResponseEntity<Map<String,Object>> deleteUser(int id) {
        Optional<User> user = userRepo.findById(id);
        Map<String,Object> body = new HashMap<>();
        if(user.isPresent()) {
        	userRepo.delete(user.get());        	
        	body.put("success", true);
        	body.put("message", "User deleted successfully");
        	return ResponseEntity.ok(body);
        }
        body.put("success", false);
    	body.put("message", "User not found");
    	return new ResponseEntity<Map<String,Object>>(body,HttpStatus.NOT_FOUND);
    }
}
