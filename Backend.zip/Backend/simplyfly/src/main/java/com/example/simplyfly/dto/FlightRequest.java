package com.example.simplyfly.dto;

import com.example.simplyfly.entity.User;

public class FlightRequest {
    private String flightNumber;
    private String flightName;
    private Integer checkinKg;
    private Integer cabinKg;
    private Integer ownerUserId;
    private User owner;
    private int totalSeats;
    private int economySeats;
    private int businessSeats;
    private int premiumEconomySeats;
    private int firstClassSeats;
    
	public int getTotalSeats() {
		return totalSeats;
	}
	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}
	public User getOwner() {
		return owner;
	}
	public void setOwner(User owner) {
		this.owner = owner;
	}
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public Integer getCheckinKg() {
		return checkinKg;
	}
	public void setCheckinKg(Integer checkinKg) {
		this.checkinKg = checkinKg;
	}
	public Integer getCabinKg() {
		return cabinKg;
	}
	public void setCabinKg(Integer cabinKg) {
		this.cabinKg = cabinKg;
	}
	public Integer getOwnerUserId() {
		return ownerUserId;
	}
	public void setOwnerUserId(Integer ownerUserId) {
		this.ownerUserId = ownerUserId;
	}
	public int getEconomySeats() {
		return economySeats;
	}
	public void setEconomySeats(int economySeats) {
		this.economySeats = economySeats;
	}
	public int getBusinessSeats() {
		return businessSeats;
	}
	public void setBusinessSeats(int businessSeats) {
		this.businessSeats = businessSeats;
	}
	public int getPremiumEconomySeats() {
		return premiumEconomySeats;
	}
	public void setPremiumEconomySeats(int premiumEconomySeats) {
		this.premiumEconomySeats = premiumEconomySeats;
	}
	public int getFirstClassSeats() {
		return firstClassSeats;
	}
	public void setFirstClassSeats(int firstClassSeats) {
		this.firstClassSeats = firstClassSeats;
	}

}
