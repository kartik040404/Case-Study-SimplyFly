package com.example.simplyfly.entity;

import jakarta.persistence.*;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "booking_seats")
public class BookingSeat {
	 @Id   @GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
	  @ManyToOne  Booking booking;
	  @ManyToOne private Seat seat;
	  
	  public BookingSeat() {
		super();
	}

	  public BookingSeat(Integer id, Booking booking, Seat seat) {
		super();
		this.id = id;
		this.booking = booking;
		this.seat = seat;
	}
	  

	  public Integer getId() {
		return id;
	}

	  public void setId(Integer id) {
		  this.id = id;
	  }

	  public Booking getBooking() {
		  return booking;
	  }

	  public void setBooking(Booking booking) {
		  this.booking = booking;
	  }

	  public Seat getSeat() {
		  return seat;
	  }

	  public void setSeat(Seat seat) {
		  this.seat = seat;
	  }

	  @Override
	  public String toString() {
		return "BookingSeat [id=" + id + ", booking=" + booking + ", seat=" + seat + "]";
	  }
	  
}
