package com.example.simplyfly.controller;

import com.example.simplyfly.entity.Flight;
import com.example.simplyfly.service.FlightService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/flights")
public class FlightController {

    @Autowired
    private FlightService flightService;

    @GetMapping
    public ResponseEntity<Map<String,Object>> getAllFlights() {
        return flightService.getAllFlights();
    }

    @GetMapping("/{flightId}")
    public ResponseEntity<Map<String,Object>> getFlightById(@PathVariable int flightId) {
        return flightService.getFlightById(flightId);
    }

    @PostMapping
    public ResponseEntity<Map<String,Object>> createFlight(@RequestBody Flight flight) {
        return flightService.createFlight(flight);
    }

    @PutMapping("/{flightId}")
    public ResponseEntity<Map<String,Object>> updateFlight(
            @PathVariable int flightId,
            @RequestBody Flight flightDetails) {
        return flightService.updateFlight(flightId, flightDetails);
    }

    @DeleteMapping("/{flightId}")
    public ResponseEntity<Map<String,Object>> deleteFlight(@PathVariable int flightId) {
        return flightService.deleteFlight(flightId);
    }
}
