package com.example.simplyfly.enums;

public enum Role { PASSENGER, FLIGHT_OWNER, ADMIN }

