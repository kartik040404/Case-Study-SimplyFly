package com.example.simplyfly.dto;

public class BookingDTO {
    public int    bookingId;
    public String origin, destination;    // from route
    public String flightNumber, flightName;
    public double totalAmount;
    public String status;
}
