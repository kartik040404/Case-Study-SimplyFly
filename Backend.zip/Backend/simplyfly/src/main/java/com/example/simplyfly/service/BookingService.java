package com.example.simplyfly.service;

import com.example.simplyfly.entity.Booking;
import com.example.simplyfly.entity.BookingHistory;
import com.example.simplyfly.entity.Payment;
import com.example.simplyfly.entity.Route;
import com.example.simplyfly.entity.Seat;
import com.example.simplyfly.enums.BookingStatus;
import com.example.simplyfly.enums.HistoryAction;
import com.example.simplyfly.enums.PaymentStatus;
import com.example.simplyfly.repository.BookingHistoryRepo;
import com.example.simplyfly.repository.BookingRepo;
import com.example.simplyfly.repository.PaymentRepo;

import jakarta.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class BookingService {

    @Autowired
    private BookingRepo bookingRepo;
    
    @Autowired
    private BookingHistoryRepo bookingHistoryRepo;
    
    @Autowired
    private PaymentRepo paymentRepo;
    
    @Autowired
    private EmailService emailService;
    
//    public ResponseEntity<Map<String,Object>> getAllBookings() {
//        List<Booking> bookings = bookingRepo.findAll();
//        Map<String,Object> body = new HashMap<>();
//        body.put("success", true);
//        body.put("data", bookings);
//        return ResponseEntity.ok(body);
//    }
    public ResponseEntity<Map<String,Object>> getAllBookings() {
        List<Booking> list = bookingRepo.findAll();
        List<Map<String,Object>> data = list.stream().map(b -> {
            Map<String,Object> m = new HashMap<>();
            m.put("bookingId",    b.getBookingId());
            m.put("userId",       b.getUser() != null ? b.getUser().getUserID() : "-");
            m.put("userEmail",    b.getUser() != null ? b.getUser().getEmail() : "-");
            m.put("origin",       b.getRoute() != null ? b.getRoute().getOrigin() : "-");
            m.put("destination",  b.getRoute() != null ? b.getRoute().getDestination() : "-");
            m.put("totalAmount",  b.getTotalAmount());
            m.put("status",       b.getStatus() != null ? b.getStatus().name() : "-");
            m.put("bookedAt",     b.getBookedAt() != null ? b.getBookedAt() : "-");
            return m;
        }).toList();

        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", data);
        return ResponseEntity.ok(body);
    }



//    public ResponseEntity<Map<String,Object>> getBookingById(int id) {
//        Optional<Booking> opt = bookingRepo.findById(id);
//        Map<String,Object> body = new HashMap<>();
//        if (opt.isPresent()) {
//            body.put("success", true);
//            body.put("data", opt.get());
//            return ResponseEntity.ok(body);
//        } else {
//            body.put("success", false);
//            body.put("message", "Booking not found with id " + id);
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
//        }
//    }
    public Booking findById(int bookingId) {
        return bookingRepo.findById(bookingId)
            .orElseThrow(() ->
                new EntityNotFoundException("Booking not found with id " + bookingId));
    }
    
    public ResponseEntity<Map<String,Object>> getBookingById( int id) {
        Optional<Booking> opt = bookingRepo.findById(id);
        Map<String,Object> body = new HashMap<>();

        if (opt.isPresent()) {
            Booking b = opt.get();

            // build booking data
            Map<String,Object> bookingData = new HashMap<>();
            bookingData.put("bookingId",    b.getBookingId());
            bookingData.put("status",       b.getStatus().name());
            bookingData.put("totalAmount",  b.getTotalAmount());
            bookingData.put("bookedAt",     b.getBookedAt());
            bookingData.put("user", Map.of(
                "userID", b.getUser().getUserID(),
                "email",  b.getUser().getEmail()
            ));

            Route r = b.getRoute();
            Map<String,Object> routeData = new HashMap<>();
            routeData.put("routeId", r.getRouteId());
            routeData.put("origin", r.getOrigin());
            routeData.put("destination", r.getDestination());
            routeData.put("departureTs", r.getDepartureTs());
            routeData.put("arrivalTs", r.getArrivalTs());
            routeData.put("economyFare", r.getEconomyFare());
            routeData.put("businessFare", r.getBusinessFare());
            routeData.put("premiumEconomyFare", r.getPremiumEconomyFare());
            routeData.put("firstClassFare", r.getFirstClassFare());
            routeData.put("flightNumber", r.getFlight().getFlightNumber());
            routeData.put("flightName",   r.getFlight().getFlightName());

            bookingData.put("route", routeData);

            List<Map<String,Object>> allSeats = r.getSeats().stream().map(s -> {
                Map<String,Object> m = new HashMap<>();
                m.put("seatId",     s.getSeatId());
                m.put("seatNumber", s.getSeatNumber());
                m.put("classType",  s.getClassType().name());
                m.put("status",     s.getStatus().name());
                m.put("fare", switch (s.getClassType()) {
                    case ECONOMY         -> r.getEconomyFare();
                    case BUSINESS        -> r.getBusinessFare();
                    case PREMIUM_ECONOMY -> r.getPremiumEconomyFare();
                    case FIRST_CLASS     -> r.getFirstClassFare();
                });
                return m;
            }).toList();


            bookingData.put("allSeats", allSeats);

            List<Integer> bookedSeatIds = b.getRoute().getSeats().stream()
                .map(Seat::getSeatId)
                .toList();
            bookingData.put("bookedSeatIds", bookedSeatIds);

            body.put("success", true);
            body.put("data", bookingData);
            return ResponseEntity.ok(body);
        } else {
            body.put("success", false);
            body.put("message", "Booking not found with id " + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
    }


    public ResponseEntity<Map<String,Object>> createBooking(Booking booking) {
        Booking saved = bookingRepo.save(booking);
        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("message", "Booking created successfully");
        body.put("data", saved);
        return ResponseEntity.ok(body);
    }

    public ResponseEntity<Map<String,Object>> updateBooking(int id, Booking details) {
        Optional<Booking> opt = bookingRepo.findById(id);
        Map<String,Object> body = new HashMap<>();
        if (opt.isPresent()) {
            Booking booking = opt.get();
            booking.setUser(details.getUser());
            booking.setRoute(details.getRoute());
            booking.setTotalAmount(details.getTotalAmount());
            booking.setBookedAt(details.getBookedAt());
            booking.setStatus(details.getStatus());
            Booking updated = bookingRepo.save(booking);
            body.put("success", true);
            body.put("message", "Booking updated successfully");
            body.put("data", updated);
            return ResponseEntity.ok(body);
        } else {
            body.put("success", false);
            body.put("message", "Booking not found with id " + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
    }

    public ResponseEntity<Map<String,Object>> deleteBooking(int id) {
        Optional<Booking> opt = bookingRepo.findById(id);
        Map<String,Object> body = new HashMap<>();
        if (opt.isPresent()) {
//            bookingRepo.delete(opt.get());
        	opt.get().setStatus(BookingStatus.CANCELLED);
  
        	
            body.put("success", true);
            body.put("message", "Booking deleted successfully");
            
            return ResponseEntity.ok(body);
        } else {
            body.put("success", false);
            body.put("message", "Booking not found with id " + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
    }
    
    
    public ResponseEntity<Map<String, Object>> cancelBooking(int id) {
        Optional<Booking> opt = bookingRepo.findById(id);
        Map<String, Object> body = new HashMap<>();

        if (opt.isPresent()) {
            Booking booking = opt.get();

            booking.setStatus(BookingStatus.CANCELLED);
            bookingRepo.save(booking); 
            
            Payment payment = paymentRepo.findByBooking(booking);
            if (payment != null) {
                payment.setPaymentStatus(PaymentStatus.REFUND); 
                paymentRepo.save(payment);
            }

            try {
            emailService.sendCancellationEmail(booking);
            } catch (Exception e) {
                e.printStackTrace(); 
            }
            body.put("success", true);
            body.put("message", "Booking cancelled successfully");
            return ResponseEntity.ok(body);
        } else {
            body.put("success", false);
            body.put("message", "Booking not found with id " + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
    }

    
//    public ResponseEntity<Map<String,Object>> getBookingsByUser(int userId) {
//        List<Booking> list = bookingRepo.findByUserUserID(userId);
//        List<Map<String,Object>> data = list.stream().map(b -> {
//            Map<String,Object> m = new HashMap<>();
//            m.put("bookingId",    b.getBookingId());
//            m.put("origin",       b.getRoute().getOrigin());
//            m.put("destination",  b.getRoute().getDestination());
//            m.put("totalAmount",  b.getTotalAmount());
//            m.put("status",       b.getStatus().name()); 
//            return m;
//        }).toList();
//
//        Map<String,Object> body = new HashMap<>();
//        body.put("success", true);
//        body.put("data",    data);
//        return ResponseEntity.ok(body);
//    }
    public ResponseEntity<Map<String,Object>> getBookingsByBookId(int userId) {
        List<Booking> list = bookingRepo.findByUserUserID(userId);
        LocalDateTime now = LocalDateTime.now();

        List<Map<String,Object>> data = list.stream()
            .filter(b -> b.getStatus() == BookingStatus.BOOKED 
                      && b.getRoute().getArrivalTs().isAfter(now))
            .map(b -> {
                Map<String,Object> m = new HashMap<>();
                m.put("bookingId",    b.getBookingId());
                m.put("origin",       b.getRoute().getOrigin());
                m.put("destination",  b.getRoute().getDestination());
                m.put("totalAmount",  b.getTotalAmount());
                m.put("status",       b.getStatus().name());
                return m;
            }).toList();

        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data",    data);
        return ResponseEntity.ok(body);
    }
    
    public ResponseEntity<Map<String,Object>> getBookingHistory(int userId) {
        List<Booking> list = bookingRepo.findByUserUserID(userId);
        LocalDateTime now = LocalDateTime.now();

        List<Map<String,Object>> data = list.stream()
            .filter(b -> b.getStatus() == BookingStatus.CANCELLED
                      && b.getRoute().getDepartureTs().isBefore(now))
            .map(b -> {
                Map<String,Object> m = new HashMap<>();
                m.put("bookingId",    b.getBookingId());
                m.put("origin",       b.getRoute().getOrigin());
                m.put("destination",  b.getRoute().getDestination());
                m.put("totalAmount",  b.getTotalAmount());
                m.put("status",       b.getStatus().name());
                return m;
            }).toList();

        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data",    data);
        return ResponseEntity.ok(body);
    }

}
