package com.example.simplyfly.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.simplyfly.entity.Booking;

public interface BookingRepo extends JpaRepository<Booking,Integer>{
	List<Booking> findByUserUserID(int userId);

}
