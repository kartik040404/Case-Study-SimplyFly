package com.example.simplyfly.service;


import com.example.simplyfly.dto.SeatDTO;
import com.example.simplyfly.entity.Route;
import com.example.simplyfly.entity.Seat;
import com.example.simplyfly.repository.RouteRepo;
import com.example.simplyfly.repository.SeatRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class SeatService {

    @Autowired
    private SeatRepo seatRepo;
    
    @Autowired
    private RouteRepo routeRepo;

//    public ResponseEntity<Map<String,Object>> getSeatsByRoute(int routeId) {
//        List<Seat> all = seatRepo.findAll();
//        List<Seat> seats = all.stream()
//            .filter(s -> s.getRoute() != null && s.getRoute().getRouteId() == routeId)
//            .collect(Collectors.toList());
//
//        Map<String,Object> body = new HashMap<>();
//        body.put("success", true);
//        body.put("data", seats);
//        return ResponseEntity.ok(body);
//    }
    
    public ResponseEntity<Map<String,Object>> getSeatsByRoute(int routeId) {
        // fetch the route once to get its fares
        Route route = routeRepo.findById(routeId)
                       .orElseThrow(() -> new NoSuchElementException("Route not found"));

        // now fetch only seats for that route
        List<SeatDTO> dtos = seatRepo.findByRoute_RouteId(routeId).stream()
            .map(s -> {
                double fare;
                switch(s.getClassType()) {
                  case ECONOMY:       fare = route.getEconomyFare();        break;
                  case BUSINESS:      fare = route.getBusinessFare();       break;
                  case PREMIUM_ECONOMY: fare = route.getPremiumEconomyFare(); break;
                  case FIRST_CLASS:   fare = route.getFirstClassFare();     break;
                  default:            fare = 0;
                }
                return new SeatDTO(
                  s.getSeatId(),
                  s.getSeatNumber(),
                  s.getClassType(),
                  fare
                );
            })
            .collect(Collectors.toList());

        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data",    dtos);
        return ResponseEntity.ok(body);
    }

    public ResponseEntity<Map<String,Object>> getSeatById(int id) {
        Optional<Seat> opt = seatRepo.findById(id);
        Map<String,Object> body = new HashMap<>();
        if (opt.isPresent()) {
            body.put("success", true);
            body.put("data", opt.get());
            return ResponseEntity.ok(body);
        } else {
            body.put("success", false);
            body.put("message", "Seat not found with id " + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
    }

    public ResponseEntity<Map<String,Object>> createSeat(Seat seat) {
        Seat saved = seatRepo.save(seat);
        Map<String,Object> body = new HashMap<>();
        body.put("success", true);
        body.put("message", "Seat created successfully");
        body.put("data", saved);
        return ResponseEntity.ok(body);
    }

    public ResponseEntity<Map<String,Object>> updateSeat(int id, Seat details) {
        Optional<Seat> opt = seatRepo.findById(id);
        Map<String,Object> body = new HashMap<>();
        if (opt.isPresent()) {
            Seat seat = opt.get();
            seat.setRoute(details.getRoute());
            seat.setSeatNumber(details.getSeatNumber());
            seat.setClassType(details.getClassType());
            seat.setStatus(details.getStatus());
            Seat updated = seatRepo.save(seat);
            body.put("success", true);
            body.put("message", "Seat updated successfully");
            body.put("data", updated);
            return ResponseEntity.ok(body);
        } else {
            body.put("success", false);
            body.put("message", "Seat not found with id " + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
    }
}
