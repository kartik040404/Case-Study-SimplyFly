package com.example.simplyfly.enums;

public enum SeatStatus { AVAILABLE, BOOKED }

