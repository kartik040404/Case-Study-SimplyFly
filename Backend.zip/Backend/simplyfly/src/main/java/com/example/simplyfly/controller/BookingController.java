package com.example.simplyfly.controller;


import com.example.simplyfly.entity.Booking;
import com.example.simplyfly.service.BookingService;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import com.stripe.param.checkout.SessionCreateParams.PaymentMethodType;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @Value("${stripe.secret.key}")
    private String stripeSecretKey;

    @PostConstruct
    public void initStripe() {
        Stripe.apiKey = stripeSecretKey;
    }
    
    @GetMapping
    public ResponseEntity<Map<String,Object>> getAllBookings() {
        return bookingService.getAllBookings();
    }

    @GetMapping("/{bookingId}")
    public ResponseEntity<Map<String,Object>> getBookingById(@PathVariable int bookingId) {
        return bookingService.getBookingById(bookingId);
    }

    @PostMapping
    public ResponseEntity<Map<String,Object>> createBooking(@RequestBody Booking booking) {
        return bookingService.createBooking(booking);
    }

    @PutMapping("/{bookingId}")
    public ResponseEntity<Map<String,Object>> updateBooking(
            @PathVariable int bookingId,
            @RequestBody Booking bookingDetails) {
        return bookingService.updateBooking(bookingId, bookingDetails);
    }

    @DeleteMapping("/{bookingId}")
    public ResponseEntity<Map<String,Object>> deleteBooking(@PathVariable int bookingId) {
        return bookingService.deleteBooking(bookingId);
    }
    
    @PutMapping("/cancel/{bookingId}")
    public ResponseEntity<Map<String,Object>> cancelBooking(@PathVariable int bookingId) {
        return bookingService.cancelBooking(bookingId);
    }
    
    @GetMapping("/api/users/{userId}/bookings")
    public ResponseEntity<Map<String,Object>> getByUser(@PathVariable int userId) {
        return bookingService.getBookingsByBookId(userId);
    }
    
    @GetMapping("/history/{userId}")
    public ResponseEntity<Map<String,Object>> getBookingHistory(@PathVariable int userId) {
        return bookingService.getBookingHistory(userId);
    }
    
    
    @PostMapping("/{bookingId}/createStripeSession")
    public Map<String,String> createStripeSession(@PathVariable int bookingId,HttpServletRequest request) throws StripeException {
        Booking booking = bookingService.findById(bookingId);

        BigDecimal totalAmount = BigDecimal.valueOf(booking.getTotalAmount());
        long amountInPaise = totalAmount
            .multiply(BigDecimal.valueOf(100))
            .longValue();

        String origin = request.getHeader("Origin"); 

        SessionCreateParams params = SessionCreateParams.builder()
             .addPaymentMethodType(PaymentMethodType.CARD)

            .setMode(SessionCreateParams.Mode.PAYMENT)
            .setSuccessUrl(origin + "/payment-success?session_id={CHECKOUT_SESSION_ID}&bookingId=" + bookingId)
            .setCancelUrl(origin + "/passenger/dashboard/bookings")
            .addLineItem(SessionCreateParams.LineItem.builder()
                .setQuantity(1L)
                .setPriceData(
                  SessionCreateParams.LineItem.PriceData.builder()
                    .setCurrency("inr")
                    .setUnitAmount(amountInPaise)
                    .setProductData(
                      SessionCreateParams.LineItem.PriceData.ProductData.builder()
                        .setName("Booking #" + bookingId)
                        .build()
                    ).build()
                ).build()
            ).build();

        Session session = Session.create(params);
        return Map.of("sessionId", session.getId());
    }
    
}
