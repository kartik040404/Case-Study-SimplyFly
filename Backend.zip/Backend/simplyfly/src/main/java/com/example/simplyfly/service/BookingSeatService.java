package com.example.simplyfly.service;
 
import com.example.simplyfly.entity.Booking;
import com.example.simplyfly.entity.BookingSeat;
import com.example.simplyfly.entity.Seat;
import com.example.simplyfly.repository.BookingRepo;
import com.example.simplyfly.repository.BookingSeatRepo;
import com.example.simplyfly.repository.SeatRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.*;

@Service
public class BookingSeatService {

    @Autowired
    private BookingSeatRepo bookingSeatRepo;

    @Autowired
    private BookingRepo bookingRepo;

    @Autowired
    private SeatRepo seatRepo;

    public ResponseEntity<Map<String,Object>> addSeatToBooking(int bookingId, BookingSeat details) {
        Map<String,Object> body = new HashMap<>();

        Optional<Booking> optBooking = bookingRepo.findById(bookingId);
        if (optBooking.isEmpty()) {
            body.put("success", false);
            body.put("message", "Booking not found with id " + bookingId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }

        Integer seatId = details.getSeat() != null ? details.getSeat().getSeatId() : null;
        if (seatId == null) {
            body.put("success", false);
            body.put("message", "Seat ID must be provided");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }

        Optional<Seat> optSeat = seatRepo.findById(seatId);
        if (optSeat.isEmpty()) {
            body.put("success", false);
            body.put("message", "Seat not found with id " + seatId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }

        BookingSeat bs = new BookingSeat();
        bs.setId(details.getId());
        bs.setBooking(optBooking.get());
        bs.setSeat(optSeat.get());

        BookingSeat saved = bookingSeatRepo.save(bs);
        body.put("success", true);
        body.put("message", "Seat added to booking successfully");
        body.put("data", saved);
        return ResponseEntity.ok(body);
    }

    public ResponseEntity<Map<String,Object>> removeSeatFromBooking(int bookingId, int seatId) {
        Map<String,Object> body = new HashMap<>();

        // find matching association
        Optional<BookingSeat> optBs = bookingSeatRepo.findAll().stream()
            .filter(bs -> bs.getBooking() != null
                       && bs.getBooking().getBookingId() == bookingId
                       && bs.getSeat()    != null
                       && bs.getSeat().getSeatId() == seatId)
            .findFirst();

        if (optBs.isEmpty()) {
            body.put("success", false);
            body.put("message", "No seat association found for booking " 
                          + bookingId + " and seat " + seatId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }

        bookingSeatRepo.delete(optBs.get());
        body.put("success", true);
        body.put("message", "Seat removed from booking successfully");
        return ResponseEntity.ok(body);
    }
}
