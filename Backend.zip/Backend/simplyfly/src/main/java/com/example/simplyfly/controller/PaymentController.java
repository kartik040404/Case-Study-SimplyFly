package com.example.simplyfly.controller;

import com.example.simplyfly.entity.Payment;
import com.example.simplyfly.service.PaymentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/bookings/{bookingId}/payments")
    public ResponseEntity<Map<String,Object>> addPaymentToBooking(@PathVariable int bookingId,@RequestBody Payment payment) {
        return paymentService.addPaymentToBooking(bookingId, payment);
    }

    @GetMapping("/payments/{paymentId}")
    public ResponseEntity<Map<String,Object>> getPaymentById(@PathVariable int paymentId) {
        return paymentService.getPaymentById(paymentId);
    }

    @GetMapping("/bookings/{bookingId}/payments")
    public ResponseEntity<Map<String,Object>> getPaymentsForBooking(@PathVariable int bookingId) {
        return paymentService.getPaymentsForBooking(bookingId);
    }
}
