package com.example.simplyfly.controller;


import com.example.simplyfly.entity.Seat;
import com.example.simplyfly.service.SeatService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/seats")
public class SeatController {

    @Autowired
    private SeatService seatService;

    @GetMapping("/routes/{routeId}/seats")
    public ResponseEntity<Map<String,Object>> getSeatsByRoute(@PathVariable int routeId) {
        return seatService.getSeatsByRoute(routeId);
    }

    @GetMapping("/{seatId}")
    public ResponseEntity<Map<String,Object>> getSeatById(@PathVariable int seatId) {
        return seatService.getSeatById(seatId);
    }

    @PostMapping
    public ResponseEntity<Map<String,Object>> createSeat(@RequestBody Seat seat) {
        return seatService.createSeat(seat);
    }

    @PutMapping("/{seatId}")
    public ResponseEntity<Map<String,Object>> updateSeat(
            @PathVariable int seatId,
            @RequestBody Seat seatDetails) {
        return seatService.updateSeat(seatId, seatDetails);
    }
}
