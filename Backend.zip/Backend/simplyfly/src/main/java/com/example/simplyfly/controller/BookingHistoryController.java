package com.example.simplyfly.controller;

import com.example.simplyfly.service.BookingHistoryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
public class BookingHistoryController {

    @Autowired
    private BookingHistoryService bookingHistoryService;

    @GetMapping("/{bookingId}/history")
    public ResponseEntity<Map<String,Object>> getBookingHistory(@PathVariable int bookingId) {
        return bookingHistoryService.getBookingHistory(bookingId);
    }
}
