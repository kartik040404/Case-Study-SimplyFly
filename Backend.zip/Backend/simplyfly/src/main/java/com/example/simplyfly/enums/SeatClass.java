package com.example.simplyfly.enums;

public enum SeatClass { ECONOMY, BUSINESS,PREMIUM_ECONOMY,FIRST_CLASS }

