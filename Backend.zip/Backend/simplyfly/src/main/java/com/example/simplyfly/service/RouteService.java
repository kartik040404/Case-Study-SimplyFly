package com.example.simplyfly.service;


import com.example.simplyfly.dto.RouteDTO;
import com.example.simplyfly.dto.RouteSummaryDTO;
import com.example.simplyfly.entity.Flight;
import com.example.simplyfly.entity.Route;
import com.example.simplyfly.entity.Seat;
import com.example.simplyfly.enums.SeatClass;
import com.example.simplyfly.enums.SeatStatus;
import com.example.simplyfly.repository.FlightRepo;
import com.example.simplyfly.repository.RouteRepo;
import com.example.simplyfly.repository.SeatRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class RouteService {

    @Autowired
    private RouteRepo routeRepo;
    
    @Autowired
    private SeatRepo seatRepo;
    
    @Autowired
    private FlightRepo flightRepo;
    
    public RouteService() {
		// TODO Auto-generated constructor stub
	}

//    public ResponseEntity<Map<String,Object>> getAllRoutes() {
//        List<Route> routes = routeRepo.findAll();
//        Map<String,Object> body = new HashMap<>();
//        body.put("success", true);
//        body.put("data", routes);
//        return ResponseEntity.ok(body);
//    }
//    @GetMapping("/api/routes")
    public ResponseEntity<Map<String, Object>> getAllRoutes() {
        List<Route> routes = routeRepo.findAll();

        List<Map<String, Object>> data = routes.stream().map(r -> {
            Map<String, Object> m = new HashMap<>();
            m.put("routeId", r.getRouteId());
            m.put("origin", r.getOrigin());
            m.put("destination", r.getDestination());
            m.put("departureTs", r.getDepartureTs());
            m.put("arrivalTs", r.getArrivalTs());
            m.put("economyFare", r.getEconomyFare());
            m.put("businessFare", r.getBusinessFare());
            m.put("premiumEconomyFare", r.getPremiumEconomyFare());
            m.put("firstClassFare", r.getFirstClassFare());

            Map<String, Object> flight = new HashMap<>();
            flight.put("flightId", r.getFlight().getFlightId());
            flight.put("flightNumber", r.getFlight().getFlightNumber());
            flight.put("flightName", r.getFlight().getFlightName());
            flight.put("userID", r.getFlight().getOwner().getUserID());

            m.put("flight", flight);

            return m;
        }).toList();

        Map<String, Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", data);
        return ResponseEntity.ok(body);
    }


//    public ResponseEntity<Map<String,Object>> getRouteById(int id) {
//        Optional<Route> opt = routeRepo.findById(id);
//        Map<String,Object> body = new HashMap<>();
//        if (opt.isPresent()) {
//            body.put("success", true);
//            body.put("data", opt.get());
//            return ResponseEntity.ok(body);
//        } else {
//            body.put("success", false);
//            body.put("message", "Route not found with id " + id);
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
//        }
//    }
    
    public ResponseEntity<Map<String,Object>> getRouteById(int routeId) {
        Optional<Route> opt = routeRepo.findById(routeId);
        Map<String,Object> body = new HashMap<>();
        if (opt.isEmpty()) {
            body.put("success", false);
            body.put("message", "Route not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
        Route r = opt.get();
        // build DTO
        RouteDTO dto = new RouteDTO();
        dto.routeId             = r.getRouteId();
        dto.origin              = r.getOrigin();
        dto.destination         = r.getDestination();
        dto.departureTs         = r.getDepartureTs();
        dto.arrivalTs           = r.getArrivalTs();
        dto.flightNumber        = r.getFlight().getFlightNumber();
        dto.flightName          = r.getFlight().getFlightName();
        dto.economyFare         = r.getEconomyFare();
        dto.businessFare        = r.getBusinessFare();
        dto.premiumEconomyFare  = r.getPremiumEconomyFare();
        dto.firstClassFare      = r.getFirstClassFare();

        body.put("success", true);
        body.put("data",    dto);
        return ResponseEntity.ok(body);
    }


//    public ResponseEntity<Map<String,Object>> createRoute(Route route) {
//        Route saved = routeRepo.save(route);
//        Map<String,Object> body = new HashMap<>();
//        body.put("success", true);
//        body.put("message", "Route created successfully");
//        body.put("data", saved);
//        return ResponseEntity.ok(body);
//    }

	    public ResponseEntity<Map<String,Object>> createRoute(Route route) {
	        Route saved = routeRepo.save(route);
	        
	        Flight flight=flightRepo.getReferenceById(saved.getFlight().getFlightId());
	
	        System.out.println("=============================="+flight.toString());
	        List<Seat> seats = new ArrayList<>();
	        // Economy
	        for(int i=1; i<= flight.getEconomySeats(); i++){
	          seats.add(makeSeat(saved, SeatClass.ECONOMY,         "E"+i,flight.getFlightNumber()));
	        }
	        // Business
	        for(int i=1; i<= flight.getBusinessSeats(); i++){
	          seats.add(makeSeat(saved, SeatClass.BUSINESS,        "B"+i,flight.getFlightNumber()));
	        }
	        // Premium Economy
	        for(int i=1; i<= flight.getPremiumEconomySeats(); i++){
	          seats.add(makeSeat(saved, SeatClass.PREMIUM_ECONOMY, "P"+i,flight.getFlightNumber()));
	        }
	        // First Class
	        for(int i=1; i<= flight.getFirstClassSeats(); i++){
	          seats.add(makeSeat(saved, SeatClass.FIRST_CLASS,     "F"+i,flight.getFlightNumber()));
	        }
	        seatRepo.saveAll(seats);
	
	        // 3) respond
	        Map<String,Object> body = new HashMap<>();
	        body.put("success", true);
	        body.put("message", "Route created & seats generated");
	        body.put("data", saved);
	        return ResponseEntity.ok(body);
	      }
	
	      private Seat makeSeat(Route route, SeatClass cls, String suffix,String  flightNumber) {
	        Seat s = new Seat();
	        s.setRoute(route);
	        s.setClassType(cls);
	        s.setStatus(SeatStatus.AVAILABLE);
	        s.setSeatNumber(flightNumber+"-"+suffix);
	        return s;
	      }
	      
//	      @Transactional
	      public ResponseEntity<Map<String,Object>> updateRoute(int id, Route details) {
	          Optional<Route> opt = routeRepo.findById(id);
	          Map<String,Object> body = new HashMap<>();
	          if (opt.isPresent()) {
	              Route existing = opt.get();

	              // 1) Update only fields you allow
	              existing.setOrigin(details.getOrigin());
	              existing.setDestination(details.getDestination());
	              existing.setDepartureTs(details.getDepartureTs());
	              existing.setArrivalTs(details.getArrivalTs());
	              existing.setEconomyFare(details.getEconomyFare());
	              existing.setBusinessFare(details.getBusinessFare());
	              existing.setPremiumEconomyFare(details.getPremiumEconomyFare());
	              existing.setFirstClassFare(details.getFirstClassFare());

	              Route updated = routeRepo.save(existing);

	              // 2) Response
	              body.put("success", true);
	              body.put("message", "Route updated successfully");
//	              body.put("data", updated);
	              return ResponseEntity.ok(body);
	          } else {
	              body.put("success", false);
	              body.put("message", "Route not found with id " + id);
	              return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
	          }
	      }

//    public ResponseEntity<Map<String,Object>> updateRoute(int id, Route details) {
//        Optional<Route> opt = routeRepo.findById(id);
//        Map<String,Object> body = new HashMap<>();
//        if (opt.isPresent()) {
//            Route updated = routeRepo.save(details);
//            body.put("success", true);
//            body.put("message", "Route updated successfully");
//            body.put("data", updated);
//            return ResponseEntity.ok(body);
//        } else {
//            body.put("success", false);
//            body.put("message", "Route not found with id " + id);
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
//        }
//    }

    public ResponseEntity<Map<String,Object>> deleteRoute(int id) {
        Optional<Route> opt = routeRepo.findById(id);
        Map<String,Object> body = new HashMap<>();
        if (opt.isPresent()) {
            routeRepo.delete(opt.get());
            body.put("success", true);
            body.put("message", "Route deleted successfully");
            return ResponseEntity.ok(body);
        } else {
            body.put("success", false);
            body.put("message", "Route not found with id " + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
    }

//    public ResponseEntity<Map<String,Object>> searchRoutes(String origin, String destination, String date) {
//        Map<String,Object> body = new HashMap<>();
//        LocalDate parsedDate;
//        try {
//            parsedDate = LocalDate.parse(date);
//        } catch (DateTimeParseException e) {
//            body.put("success", false);
//            body.put("message", "Invalid date format. Use yyyy-MM-dd");
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
//        }
//        LocalDateTime startOfDay = parsedDate.atStartOfDay();
//        List<Route> routes = routeRepo
//            .findByOriginAndDestinationAndDepartureTsAfter(origin, destination, startOfDay);
//        body.put("success", true);
//        body.put("data", routes);
//        return ResponseEntity.ok(body);
//    }
    public ResponseEntity<Map<String,Object>> searchRoutes(
            String origin, String destination, String date
    ) {
        Map<String,Object> body = new HashMap<>();
        LocalDate parsedDate;
        try {
            parsedDate = LocalDate.parse(date);
        } catch (DateTimeParseException e) {
            body.put("success", false);
            body.put("message", "Invalid date format. Use yyyy-MM-dd");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }

        LocalDateTime startOfDay = parsedDate.atStartOfDay();
        List<Route> routes = routeRepo
            .findByOriginAndDestinationAndDepartureTsAfter(origin, destination, startOfDay);

        // Map to lightweight DTOs
        List<RouteSummaryDTO> summaries = routes.stream()
            .map(r -> {
                // pick which fare you want to show: economyFare here
//                double fareToShow = r.getEconomyFare();
                return new RouteSummaryDTO(
                    r.getRouteId(),
                    r.getOrigin(),
                    r.getDestination(),
                    r.getDepartureTs(),
                    r.getArrivalTs(),
                    r.getFlight().getFlightNumber(),
                    r.getFlight().getFlightName());
            })
            .collect(Collectors.toList());

        body.put("success", true);
        body.put("data", summaries);
        return ResponseEntity.ok(body);
    }
}
