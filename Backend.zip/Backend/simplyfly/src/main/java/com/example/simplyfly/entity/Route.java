package com.example.simplyfly.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.CascadeType;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
@Entity
@Table(name = "routes")
public class Route {
	  @Id   @GeneratedValue(strategy = GenerationType.IDENTITY)

	  private int routeId;
	 @ManyToOne private Flight flight;
	    private String origin, destination;
	    private LocalDateTime departureTs, arrivalTs;
//	    private double farePerSeat;
	    private double economyFare;
	    private double businessFare;
	    private double premiumEconomyFare;
	    private double firstClassFare;
	    @OneToMany(
	            mappedBy = "route",
	            cascade = CascadeType.ALL,
	            orphanRemoval = true
	        )
	        private List<Seat> seats = new ArrayList<>();
	    
		public Route() {
			super();
		}




		public Route(int routeId, Flight flight, String origin, String destination, LocalDateTime departureTs,
				LocalDateTime arrivalTs, double economyFare, double businessFare, double premiumEconomyFare,
				double firstClassFare, List<Seat> seats) {
			super();
			this.routeId = routeId;
			this.flight = flight;
			this.origin = origin;
			this.destination = destination;
			this.departureTs = departureTs;
			this.arrivalTs = arrivalTs;
			this.economyFare = economyFare;
			this.businessFare = businessFare;
			this.premiumEconomyFare = premiumEconomyFare;
			this.firstClassFare = firstClassFare;
			this.seats = seats;
		}




		public double getEconomyFare() {
			return economyFare;
		}




		public void setEconomyFare(double economyFare) {
			this.economyFare = economyFare;
		}




		public double getBusinessFare() {
			return businessFare;
		}




		public void setBusinessFare(double businessFare) {
			this.businessFare = businessFare;
		}




		public double getPremiumEconomyFare() {
			return premiumEconomyFare;
		}




		public void setPremiumEconomyFare(double premiumEconomyFare) {
			this.premiumEconomyFare = premiumEconomyFare;
		}




		public double getFirstClassFare() {
			return firstClassFare;
		}




		public void setFirstClassFare(double firstClassFare) {
			this.firstClassFare = firstClassFare;
		}




		public List<Seat> getSeats() {
			return seats;
		}




		public void setSeats(List<Seat> seats) {
			this.seats = seats;
		}




		public void setRouteId(int routeId) {
			this.routeId = routeId;
		}




		public Integer getRouteId() {
			return routeId;
		}


		public void setRouteId(Integer routeId) {
			this.routeId = routeId;
		}


		public Flight getFlight() {
			return flight;
		}


		public void setFlight(Flight flight) {
			this.flight = flight;
		}


		public String getOrigin() {
			return origin;
		}


		public void setOrigin(String origin) {
			this.origin = origin;
		}


		public String getDestination() {
			return destination;
		}


		public void setDestination(String destination) {
			this.destination = destination;
		}


		public LocalDateTime getDepartureTs() {
			return departureTs;
		}


		public void setDepartureTs(LocalDateTime departureTs) {
			this.departureTs = departureTs;
		}


		public LocalDateTime getArrivalTs() {
			return arrivalTs;
		}


		public void setArrivalTs(LocalDateTime arrivalTs) {
			this.arrivalTs = arrivalTs;
		}




		@Override
		public String toString() {
			return "Route [routeId=" + routeId + ", flight=" + flight + ", origin=" + origin + ", destination="
					+ destination + ", departureTs=" + departureTs + ", arrivalTs=" + arrivalTs + ", economyFare="
					+ economyFare + ", businessFare=" + businessFare + ", premiumEconomyFare=" + premiumEconomyFare
					+ ", firstClassFare=" + firstClassFare + ", seats=" + seats + ", getEconomyFare()="
					+ getEconomyFare() + ", getBusinessFare()=" + getBusinessFare() + ", getPremiumEconomyFare()="
					+ getPremiumEconomyFare() + ", getFirstClassFare()=" + getFirstClassFare() + ", getSeats()="
					+ getSeats() + ", getRouteId()=" + getRouteId() + ", getFlight()=" + getFlight() + ", getOrigin()="
					+ getOrigin() + ", getDestination()=" + getDestination() + ", getDepartureTs()=" + getDepartureTs()
					+ ", getArrivalTs()=" + getArrivalTs() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
					+ ", toString()=" + super.toString() + "]";
		}





		
	    
	    
}
