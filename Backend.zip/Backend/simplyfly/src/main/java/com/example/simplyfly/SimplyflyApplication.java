package com.example.simplyfly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//(
//		exclude = SecurityAutoConfiguration.class
//		)

public class SimplyflyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplyflyApplication.class, args);
	}

}
