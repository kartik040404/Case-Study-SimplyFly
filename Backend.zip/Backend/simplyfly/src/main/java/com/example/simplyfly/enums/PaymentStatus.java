package com.example.simplyfly.enums;

public enum PaymentStatus   { FAILED, PAID, REFUND }
