package com.example.simplyfly.controller;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.simplyfly.entity.User;
import com.example.simplyfly.enums.Role;


@SpringBootTest
public class UserControllerTest {
	@Autowired
	private UserController userController;
	@Test

	    void testRegisterUser() {
	        User user = new User(
	                "passenger",
	                "passenger@example.com",
	                "1212",
	                "Male",
	                "1212121212",
	                "Address",
	                Role.PASSENGER	        
	                );

	        ResponseEntity<Map<String, Object>> response = userController.register(user);

	        assertEquals(200, response.getStatusCode());
	        assertEquals("Register Successfully", response.getBody().get("message"));
	        assertTrue((Boolean) response.getBody().get("success"));

	        Map<String, Object> userMap = (Map<String, Object>) response.getBody().get("user");
	        assertNotNull(userMap);
	        assertEquals(user.getName(), userMap.get("name"));
	        assertEquals(user.getEmail(), userMap.get("email"));
	        assertEquals(user.getGender(), userMap.get("gender"));
	        assertEquals(user.getContactNumber(), userMap.get("contactNumber"));
	        assertEquals(user.getAddress(), userMap.get("address"));
	        assertEquals(user.getRole().toString(), userMap.get("role").toString());
	    }
	
//	@Test
//	void testGetTasks() {
//		Task task1=new Task(1,"Coding Challenge","Complete the coding Challenge",LocalDate.of(2025, 06, 26),Priority.HIGH,Status.IN_PROGRESS);   
//		Task task2=new Task(2,"REST API","Complete the REST API",LocalDate.of(2025, 06, 26),Priority.HIGH,Status.IN_PROGRESS);   
//		ResponseEntity<Task> res1=taskController.addTask(task1);
//		assertEquals(HttpStatus.CREATED, res1.getStatusCode());		
//		ResponseEntity<Task> res2=taskController.addTask(task2);
//		assertEquals(HttpStatus.CREATED, res2.getStatusCode());		
//
//		ResponseEntity<List<Task>> res=taskController.getTasks();
//		assertEquals(HttpStatus.OK, res.getStatusCode());		
//		
//		assertNotNull(res.getBody());
//		List<Task> list=res.getBody();
//
//	    assertEquals(task1.getTaskID(),res.getBody().get(0).getTaskID());
//	    assertEquals(task1.getTitle(),res.getBody().get(0).getTitle());
//	    assertEquals(task1.getDescription(),res.getBody().get(0).getDescription());
//	    assertEquals(task1.getDueDate(),res.getBody().get(0).getDueDate());
//	    assertEquals(task1.getPriority(),res.getBody().get(0).getPriority());
//	    assertEquals(task1.getStatus(),res.getBody().get(0).getStatus());
//	    
//	    assertEquals(task2.getTaskID(),res.getBody().get(1).getTaskID());
//	    assertEquals(task2.getTitle(),res.getBody().get(1).getTitle());
//	    assertEquals(task2.getDescription(),res.getBody().get(1).getDescription());
//	    assertEquals(task2.getDueDate(),res.getBody().get(1).getDueDate());
//	    assertEquals(task2.getPriority(),res.getBody().get(1).getPriority());
//	    assertEquals(task2.getStatus(),res.getBody().get(1).getStatus());
//	}
//	
//	@Test
//	void testGetByID() {
//		Task task=new Task(1,"Coding Challenge","Complete the coding Challenge",LocalDate.of(2025, 06, 26),Priority.HIGH,Status.IN_PROGRESS);   
//		ResponseEntity<Task> res1=taskController.addTask(task);
//		assertEquals(HttpStatus.CREATED, res1.getStatusCode());		
//
//		ResponseEntity<Task> res=taskController.getTask(1);
//		assertEquals(HttpStatus.OK, res.getStatusCode());		
//		
//		assertNotNull(res.getBody());
//
//	    assertEquals(task.getTaskID(),res.getBody().getTaskID());
//	    assertEquals(task.getTitle(),res.getBody().getTitle());
//	    assertEquals(task.getDescription(),res.getBody().getDescription());
//	    assertEquals(task.getDueDate(),res.getBody().getDueDate());
//	    assertEquals(task.getPriority(),res.getBody().getPriority());
//	    assertEquals(task.getStatus(),res.getBody().getStatus());
//	    
//	}
//	
//	@Test
//	void testUpdateTask() {
//		Task task=new Task(1,"Coding Challenge","Complete the coding Challenge",LocalDate.of(2025, 06, 26),Priority.HIGH,Status.IN_PROGRESS);   
//		ResponseEntity<Task> res1=taskController.addTask(task);
//		assertEquals(HttpStatus.CREATED, res1.getStatusCode());		
//		
//		task.setTitle("REST API TESING");
//		task.setDescription("Tesing REST API");
//		task.setDueDate(LocalDate.of(2025, 06, 27));
//		task.setPriority(Priority.HIGH);
//		task.setStatus(Status.COMPLETED);
//		
//		ResponseEntity<Task> res=taskController.updateTask(task,1);
//		assertEquals(HttpStatus.OK, res.getStatusCode());		
//		
//		assertNotNull(res.getBody());
//
//	    assertEquals(task.getTaskID(),res.getBody().getTaskID());
//	    assertEquals(task.getTitle(),res.getBody().getTitle());
//	    assertEquals(task.getDescription(),res.getBody().getDescription());
//	    assertEquals(task.getDueDate(),res.getBody().getDueDate());
//	    assertEquals(task.getPriority(),res.getBody().getPriority());
//	    assertEquals(task.getStatus(),res.getBody().getStatus());
//	}
//	
//	@Test
//	void testDeleteTask() {
//		Task task=new Task(1,"Coding Challenge","Complete the coding Challenge",LocalDate.of(2025, 06, 26),Priority.HIGH,Status.IN_PROGRESS);   
//		ResponseEntity<Task> res1=taskController.addTask(task);
//		assertEquals(HttpStatus.CREATED, res1.getStatusCode());		
//		
//		ResponseEntity<String> res=taskController.deleteTask(1);
//		assertEquals(HttpStatus.OK, res.getStatusCode());		
//		
//		assertNotNull(res.getBody());
//
//	    assertEquals("Task Deleted Successfully",res.getBody());
//	   
//	}
}
